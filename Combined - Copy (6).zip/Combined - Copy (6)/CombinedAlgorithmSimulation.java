import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Random;
import java.util.HashSet;
import javax.swing.SwingUtilities;

public class CombinedAlgorithmSimulation {
    
    private static int getAlgoChoice(Scanner scanner) { //the tester chooses algos 4 testing
        int choice = 0;
        while (choice < 1 || choice > 5) {
            System.out.println("\nChoose which algorithm(s) to run:");
            System.out.println("1 - Hirschberg-Sinclair (HS) Algorithm");
            System.out.println("2 - LeLann-Chang-Roberts (LCR) Algorithm");
            System.out.println("3 - Both Algorithms (using the same ring configuration)");
            System.out.println("4 - Run Performance Analysis (collects data for comparison)");
            System.out.println("5 - Launch Performance Plotter (view saved performance data)");
            System.out.print("Enter your choice (1-5): ");
            //catch cases
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice < 1 || choice > 5) {
                    System.out.println("Invalid choice. Please enter 1-5.");
                }
            } catch (NumberFormatException e) { 
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return choice;
    }
    
    private static void runHSAlgorithm(int numProcessors, List<Integer> ids, boolean shouldShuffle, int idConfiguration, boolean skipTopologyPrint) {
        List<Integer> hsIds = new ArrayList<>(ids);//create copy of IDs to avoid changing og list
        
        //init nodess with IDs
        List<HSProcessor> processors = new ArrayList<>();
        for (int id : hsIds) {
            processors.add(new HSProcessor(id));
        }
        
        //shuffle if the user selected random
        if (shouldShuffle) {
            Collections.shuffle(processors);
        }
        
        //create a bidirectional ring topology
        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
            processors.get(i).setPrev(processors.get((i - 1 + numProcessors) % numProcessors));
        }
        
        //output the ring topology for HS unless weve showed them for shared one already
        if (!skipTopologyPrint) {
            System.out.println("\nRing Topology for HS Algorithm:");
            for (HSProcessor p : processors) {
                System.out.println("Processor " + p.getId() + " -> Next: Processor " + p.getNextId() + ", Prev: Processor " + p.getPrevId());
            }
        }
        
        //run the HS leader election algo
        System.out.println("\n== Starting HS Leader Election Algorithm ==");
        long startTime = System.currentTimeMillis();
        int hsRounds = HSAlgorithm.simulate(processors); //needed for analysis
        long electionTime = System.currentTimeMillis() - startTime;
        
        //find elected leader with algo's natural execution
        int leaderId = -1;
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                leaderId = p.getId();
                break;
            }
        }
        
        // check if a leader was found
        if (leaderId == -1) {
            System.out.println("\nWARNING: No leader was elected by the HS algorithm.");
            
            // output stats before flooding phase
            System.out.println("\n======= HS Algorithm Final Statistics =======");
            System.out.println("HS Algorithm:");
            System.out.println("  - Processors: " + numProcessors);
            System.out.println("  - ID Configuration: " + (idConfiguration == 1 ? "Increasing" : idConfiguration == 2 ? "Decreasing" : "Random"));
            System.out.println("  - Rounds: " + hsRounds);
            System.out.println("  - Messages: " + HSAlgorithm.getTotalMessages());
            System.out.println("  - Leader elected: None");
            System.out.println("  - Execution time: " + electionTime + " ms");
            System.out.println("============================================");
            return;
        }
        
        // HS Broadcast stats
        System.out.println("\n== Starting Leader Announcement via Flooding (HS) ==");
        startTime = System.currentTimeMillis();
        int floodingRounds = UnidirectionalFlooding.announceLeaderHS(processors, leaderId);
        long floodingTime = System.currentTimeMillis() - startTime;
        
        //output final ultimate stats 4 LCR
        System.out.println("\n======= HS Algorithm Final Statistics =======");
        System.out.println("HS Algorithm:");
        System.out.println("  - Processors: " + numProcessors);
        System.out.println("  - ID Configuration: " + (idConfiguration == 1 ? "Increasing" : idConfiguration == 2 ? "Decreasing" : "Random"));
        System.out.println("  - Rounds: " + hsRounds);
        System.out.println("  - Messages: " + HSAlgorithm.getTotalMessages());
        System.out.println("  - Leader elected: Processor " + leaderId);
        System.out.println("  - Execution time: " + electionTime + " ms");
        
        System.out.println("\nFlooding Algorithm (HS):");
        System.out.println("  - Rounds: " + floodingRounds);
        System.out.println("  - Messages: " + UnidirectionalFlooding.getTotalHSFloodingMessages());
        System.out.println("  - Execution time: " + floodingTime + " ms");
        
        int totalRounds = hsRounds + floodingRounds;
        int totalMessages = HSAlgorithm.getTotalMessages() + UnidirectionalFlooding.getTotalHSFloodingMessages();
        long totalTime = electionTime + floodingTime;
        
        System.out.println("\nTotal (HS + Flooding):");
        System.out.println("  - Rounds: " + totalRounds);
        System.out.println("  - Messages: " + totalMessages);
        System.out.println("  - Execution time: " + totalTime + " ms");
        System.out.println("============================================");
    }
    
    private static void runLCRAlgorithm(int numProcessors, List<Integer> ids, boolean shouldShuffle, int idConfiguration, boolean skipTopologyPrint) {
        List<Integer> lcrIds = new ArrayList<>(ids); //create copy of IDs to avoid changing og list
        
        List<LCRProcessor> processors = new ArrayList<>();// init nodes with IDs
        for (int id : lcrIds) {
            processors.add(new LCRProcessor(id));
        }
        
        if (shouldShuffle) { // shuffle if the tester chose random
            Collections.shuffle(processors);
        }
        
        for (int i = 0; i < numProcessors; i++) { // creating a ring topology
            processors.get(i).setNext(processors.get((i + 1) % numProcessors)); // simpler conenctions this time as its unidir
        }
        
        // output LCR ring topology if shared topology not showing already already
        if (!skipTopologyPrint) {
            System.out.println("\nRing Topology for LCR Algorithm:");
            for (LCRProcessor p : processors) {
                System.out.println("Processor " + p.getId() + " -> Next: Processor " + p.getNextId());
            }
        }
        
        //run the LCR leader election algorithm
        System.out.println("\n== Starting LCR Leader Election Algorithm ==");
        long startTime = System.currentTimeMillis();
        int lcrRounds = LCRAlgorithm.simulate(processors); // needed
        long electionTime = System.currentTimeMillis() - startTime; // not so much but can be useful in th future
        
        int leaderId = processors.get(0).getLeaderId();
        
        // LCR Broadcast stats
        System.out.println("\n== Starting Leader Announcement via Flooding (LCR) ==");
        startTime = System.currentTimeMillis();
        int floodingRounds = UnidirectionalFlooding.announceLeaderLCR(processors, leaderId);
        long floodingTime = System.currentTimeMillis() - startTime;
        
        // final ultimate stats 4 LCR
        System.out.println("\n======= LCR Algorithm Final Statistics =======");
        System.out.println("LCR Algorithm:");
        System.out.println("  - Processors: " + numProcessors);
        System.out.println("  - ID Configuration: " + (idConfiguration == 1 ? "Increasing" : idConfiguration == 2 ? "Decreasing" : "Random"));
        System.out.println("  - Rounds: " + lcrRounds);
        System.out.println("  - Messages: " + LCRAlgorithm.getTotalLCRMessages());
        System.out.println("  - Leader elected: Processor " + leaderId);
        System.out.println("  - Execution time: " + electionTime + " ms");
        
        System.out.println("\nFlooding Algorithm (LCR):");
        System.out.println("  - Rounds: " + floodingRounds);
        System.out.println("  - Messages: " + UnidirectionalFlooding.getTotalLCRFloodingMessages());
        System.out.println("  - Execution time: " + floodingTime + " ms");
        
        int totalRounds = lcrRounds + floodingRounds;
        int totalMessages = LCRAlgorithm.getTotalLCRMessages() + UnidirectionalFlooding.getTotalLCRFloodingMessages();
        long totalTime = electionTime + floodingTime;
        
        System.out.println("\nTotal (LCR + Flooding):");
        System.out.println("  - Rounds: " + totalRounds);
        System.out.println("  - Messages: " + totalMessages);
        System.out.println("  - Execution time: " + totalTime + " ms");
        System.out.println("============================================");
    }
    
    //tester inputs n of nodes
    private static int getProcessorCount(Scanner scanner) {
        int numProcessors = 0;
        while (numProcessors < 2) {
            try {
                System.out.print("Enter the number of processors (>= 2): ");
                numProcessors = Integer.parseInt(scanner.nextLine());
                
                if (numProcessors < 2) {
                    System.out.println("Number of processors must be at least 2. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }
        return numProcessors;
    }
    
    //we dont know n and is topology isnt necessarily sequential or consecutive
    private static List<Integer> generateRandomIds(int numProcessors) {
        Random random = new Random();
        HashSet<Integer> uniqueIds = new HashSet<>(); //no duplicates ensures unique IDs
        List<Integer> ids = new ArrayList<>();
        
        while (uniqueIds.size() < numProcessors) {
            int newId = random.nextInt(1000) + 1; //range 1-1000 because it takes a long time to run on my machine
            if (uniqueIds.add(newId)) {  // to ensure uniqueness which is an assumption for these algos
                ids.add(newId);
            }
        }
        
        return ids;
    }
    
    // tester chooses the order
    private static int getIdConfiguration(Scanner scanner, List<Integer> ids) {
        int choice = 0;
        while (choice < 1 || choice > 3) {
            System.out.println("\nSelect ID configuration:");
            System.out.println("1 - Increasing Order");
            System.out.println("2 - Decreasing Order");
            System.out.println("3 - Random Order");
            System.out.print("Enter your choice (1-3): ");
            
            String input = scanner.nextLine();
            if (input.equals("1")) {
                Collections.sort(ids); //increasing order
                choice = 1;
            } else if (input.equals("2")) {
                ids.sort(Collections.reverseOrder()); //decreasing order
                choice = 2;
            } else if (input.equals("3")) {
                Collections.shuffle(ids); //random order
                choice = 3;
            } else { // catch case again
                System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
        return choice;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //choose algo to run
        int algorithmChoice = getAlgoChoice(scanner);
        
        // If performance analysis was chosen, run it and exit
        if (algorithmChoice == 4) {
            System.out.println("\n========== PERFORMANCE ANALYSIS MODE ==========");
            System.out.println("Running comprehensive performance analysis...");
            System.out.println("This will test both algorithms with varying processor counts and ID configurations.");
            System.out.println("Results will be saved for later analysis and comparison.");
            PerformanceDataCollector.collectPerformanceData();
            System.out.println("\nPerformance analysis completed.");
            System.out.println("You can now use option 5 to visualize the results or create your own graphs.");
            scanner.close();
            return;
        }
        
        // If performance plotter was chosen, launch it and exit
        if (algorithmChoice == 5) {
            System.out.println("\n========== LAUNCHING PERFORMANCE PLOTTER ==========");
            System.out.println("Opening the graphical performance data visualization tool...");
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new PerformancePlotter().setVisible(true);
                }
            });
            scanner.close();
            return;
        }
        
        //shared config for both algos
        int numProcessors = getProcessorCount(scanner);
        List<Integer> ids = generateRandomIds(numProcessors);
        System.out.println("\nGenerated Random " + numProcessors + " IDs: " + ids);
        
        int idConfiguration = getIdConfiguration(scanner, ids);
        boolean shouldShuffle = (idConfiguration == 3); //randomise if 3 is chosen
        
        //output shared ring topology if both algos chosen
        if (algorithmChoice == 3) {
            List<Integer> topologyIds = new ArrayList<>(ids); // copy IDs so we dont mess up the og
            List<HSProcessor> sharedTopology = new ArrayList<>();
            
            for (int id : topologyIds) {
                sharedTopology.add(new HSProcessor(id)); // HS bidirectionality chosen because HS can display both links
            }
            //if tester chose random
            if (shouldShuffle) {
                Collections.shuffle(sharedTopology); 
            }
            //creat the ring connections
            for (int i = 0; i < numProcessors; i++) {
                sharedTopology.get(i).setNext(sharedTopology.get((i + 1) % numProcessors));// connect 1st with last
                sharedTopology.get(i).setPrev(sharedTopology.get((i - 1 + numProcessors) % numProcessors));// vice versa
            }
            //Ouput topology
            System.out.println("\n============ SHARED RING TOPOLOGY ============");
            System.out.println("\nRing Topology (used by both algorithms):");
            for (HSProcessor p : sharedTopology) {
                System.out.println("Processor " + p.getId() + " -> Next: Processor " + p.getNextId() + ", Prev: Processor " + p.getPrevId());
            }
        }
        
        //create shared or seperate ring configs 
        if (algorithmChoice == 1 || algorithmChoice == 3) {
            System.out.println("\n============ HS ALGORITHM SIMULATION ============");
            runHSAlgorithm(numProcessors, ids, shouldShuffle, idConfiguration, algorithmChoice == 3);
        }
        
        if (algorithmChoice == 2 || algorithmChoice == 3) {
            System.out.println("\n============ LCR ALGORITHM SIMULATION ============");
            runLCRAlgorithm(numProcessors, ids, shouldShuffle, idConfiguration, algorithmChoice == 3);
        }
        
        System.out.println("\nSimulation(s) completed.");
        scanner.close();
    }
}