import java.util.List;
import java.util.ArrayList;

public class HSAlgorithm {
    private static int totalMessages = 0;

    public static void resetMessageCount() {
        totalMessages = 0; // fresh slate
    }

    public static int getTotalMessages() {
        return totalMessages; 
    }

    public static int simulate(List<HSProcessor> processors) {
        resetMessageCount();
        //init vars
        int round = 0;
        boolean changed = true;
        int leaderId = -1; // no leader yet
        int maxPhase = 0;// that any P has reached
        int consecutiveNoMessageRounds = 0;
        final int MAX_NO_MESSAGE_ROUNDS = 3; // stop infininte loop for wierd config issues when testing

        for (HSProcessor p : processors) { // init processors
            p.initialise();
        }

        //algo execution loop
        while (changed && round < processors.size() * 4) { // as long as something has changed and limit rounds to prevent infinite loops
            round++;
            changed = false;
            boolean messagesSent = false;
            
            //check Ps to update max phase 
            for (HSProcessor p : processors) {
                if (p.getPhase() > maxPhase) {
                    maxPhase = p.getPhase();
                }
            }
            
            System.out.println("\n--- HS Election: Round " + round + " (Max Phase: " + maxPhase + ") ---");

            // 1) process all buffered messages from prev round
            System.out.println("\n[Processing Messages]");
            for (HSProcessor p : processors) { //check for any leader declaration
                if (p.isLeader() && leaderId == -1) { //we havnt seen it yet
                    leaderId = p.getId();
                    changed = true;
                }
            }

            //2) send new messages
            System.out.println("\n[Sending Messages]");
            for (HSProcessor p : processors) {
                if (p.hasMessagesToSend()) { // get n of messages sent by P
                    int messageCount = p.sendMessages();
                    totalMessages += messageCount;        // add acc n of messages because before it was just counting nodes who sent messages
                    
                    if (messageCount > 0) { //if messages were sent this round, flag it
                        messagesSent = true;
                        changed = true;
                    }
                }
            }
            
            // round status ouptut
            System.out.println("\nStatus after Round " + round + ":");
            for (HSProcessor p : processors) {
                System.out.printf("  Processor %d: Phase=%d, %s%n", p.getId(), p.getPhase(),p.isLeader() ? "IS LEADER" : "not leader");
            }
            
            //consecutive rounds with no messages
            if (!messagesSent) {
                consecutiveNoMessageRounds++;
                System.out.println("No messages sent for " + consecutiveNoMessageRounds + " consecutive rounds");
            } else {
                consecutiveNoMessageRounds = 0;
            }
            
            //check if no messages for several rounds
            // infinty loop termination condition
            if ((leaderId != -1 && consecutiveNoMessageRounds >= 1) || 
                (consecutiveNoMessageRounds >= MAX_NO_MESSAGE_ROUNDS)) { //stop any infinite loops during testing
                
                if (leaderId != -1) {
                    System.out.println("Algorithm terminated: Leader elected and message passing stabilized.");
                } else {
                    System.out.println("Algorithm terminated: Message passing stabilized without leader election.");
                }
                break;
            }
            
            // end loop if leader elected and no messages becasue of the nature of simulation multiple leader issue
            if (leaderId != -1 && !messagesSent) {
                break;
            }
        }

        // safety mechanism for maximum rounds to stop infinity lopps
        if (round >= processors.size() * 4) {
            System.out.println("\nMaximum rounds (" + processors.size() * 4 + ") reached without natural termination.");
            
            //check any processor has elected itself as leader incase the program did a infinte loop
            boolean anyLeader = false;
            for (HSProcessor p : processors) {
                if (p.isLeader()) {
                    leaderId = p.getId();
                    anyLeader = true;
                    System.out.println("Found leader through normal algorithm execution: Processor " + leaderId);
                    break;
                }
            }
            
            if (!anyLeader) {
                System.out.println("No leader has been elected through the normal algorithm execution.");
            }
        }

        //summary stats
        System.out.println("\n=== HS Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalMessages);
        
        if (leaderId != -1) {
            System.out.println("Leader elected: Processor " + leaderId);
        } else {
            System.out.println("Leader elected: None");
        }
        
        System.out.println("Maximum phase reached: " + maxPhase);
        
        // additional check for Ps that believe they are leaders for error checking
        List<Integer> selfDeclaredLeaders = new ArrayList<>();
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                selfDeclaredLeaders.add(p.getId());
            }
        }
        // if OUT messages ret back to > 1 nodes which has happened due to the nature of simulations and configs
        if (selfDeclaredLeaders.size() > 0) {
            System.out.println("Processors that believe they are leaders: " + selfDeclaredLeaders);
            if (selfDeclaredLeaders.size() > 1) {
                System.out.println("WARNING: Multiple processors believe they are leaders!");
            }
        } else {
            System.out.println("No processor believes it is the leader.");
        }
        
        System.out.println("============================");

        return round;
    }
}