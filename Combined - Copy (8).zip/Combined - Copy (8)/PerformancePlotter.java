import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Performance plotter for generating graphs that compare HS and LCR algorithms
 * with standard complexity functions (n, n log n, n²).
 */
public class PerformancePlotter extends JFrame {
    // Data structures
    private List<Integer> processors = new ArrayList<>();
    private List<Integer> hsRounds = new ArrayList<>();
    private List<Integer> hsMessages = new ArrayList<>();
    private List<Integer> lcrRounds = new ArrayList<>();
    private List<Integer> lcrMessages = new ArrayList<>();
    
    // UI components
    private JComboBox<String> configComboBox;
    private JComboBox<String> metricComboBox;
    private PlotPanel plotPanel;
    private JButton saveImageButton;
    
    // Configuration options
    private final String[] CONFIG_OPTIONS = {
            "Increasing IDs", "Decreasing IDs", "Random IDs (Average)"
    };
    
    private final String[] METRIC_OPTIONS = {
            "Rounds", "Messages", "Messages per Round"
    };
    
    private final String[] DATA_FILES = {
            "performance_data/increasing_ids.csv",
            "performance_data/decreasing_ids.csv",
            "performance_data/random_ids.csv"
    };
    
    public PerformancePlotter() {
        setTitle("Leader Election Algorithm Performance Comparison");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Create control panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        // Configuration selection
        JLabel configLabel = new JLabel("ID Configuration:");
        configComboBox = new JComboBox<>(CONFIG_OPTIONS);
        
        // Metric selection
        JLabel metricLabel = new JLabel("Performance Metric:");
        metricComboBox = new JComboBox<>(METRIC_OPTIONS);
        
        // Refresh button
        JButton refreshButton = new JButton("Refresh Plot");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadDataAndUpdatePlot();
            }
        });
        
        // Save image button
        saveImageButton = new JButton("Save Plot as PNG");
        saveImageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                savePlotAsImage();
            }
        });
        saveImageButton.setEnabled(false);
        
        // Add components to control panel
        controlPanel.add(configLabel);
        controlPanel.add(configComboBox);
        controlPanel.add(metricLabel);
        controlPanel.add(metricComboBox);
        controlPanel.add(refreshButton);
        controlPanel.add(saveImageButton);
        
        // Add control panel to frame
        add(controlPanel, BorderLayout.NORTH);
        
        // Create plot panel
        plotPanel = new PlotPanel();
        add(new JScrollPane(plotPanel), BorderLayout.CENTER);
        
        // Initial data load attempt
        loadDataAndUpdatePlot();
    }
    
    /**
     * Loads data from selected CSV file and updates the plot
     */
    private void loadDataAndUpdatePlot() {
        int configIndex = configComboBox.getSelectedIndex();
        String filePath = DATA_FILES[configIndex];
        
        // Clear previous data
        processors.clear();
        hsRounds.clear();
        hsMessages.clear();
        lcrRounds.clear();
        lcrMessages.clear();
        
        try {
            // Check if file exists
            File file = new File(filePath);
            if (!file.exists()) {
                JOptionPane.showMessageDialog(this,
                        "Data file not found: " + filePath + "\nPlease run the performance analysis first.",
                        "File Not Found",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Read CSV file
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                // Skip header
                String line = reader.readLine();
                
                // Read data
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 7) {
                        processors.add(Integer.parseInt(parts[0]));
                        hsRounds.add(Integer.parseInt(parts[1]));
                        hsMessages.add(Integer.parseInt(parts[2]));
                        lcrRounds.add(Integer.parseInt(parts[4]));
                        lcrMessages.add(Integer.parseInt(parts[5]));
                    }
                }
            }
            
            // Update plot
            int metricIndex = metricComboBox.getSelectedIndex();
            
            switch (metricIndex) {
                case 0: // Rounds
                    plotPanel.updateData(processors, hsRounds, lcrRounds, 
                            CONFIG_OPTIONS[configIndex] + " - Rounds Comparison", 
                            "Number of Processors", "Number of Rounds");
                    break;
                case 1: // Messages
                    plotPanel.updateData(processors, hsMessages, lcrMessages, 
                            CONFIG_OPTIONS[configIndex] + " - Messages Comparison", 
                            "Number of Processors", "Number of Messages");
                    break;
                case 2: // Messages per Round
                    List<Double> hsMessagesPerRound = new ArrayList<>();
                    List<Double> lcrMessagesPerRound = new ArrayList<>();
                    
                    for (int i = 0; i < processors.size(); i++) {
                        hsMessagesPerRound.add((double) hsMessages.get(i) / hsRounds.get(i));
                        lcrMessagesPerRound.add((double) lcrMessages.get(i) / lcrRounds.get(i));
                    }
                    
                    plotPanel.updateDoubleData(processors, hsMessagesPerRound, lcrMessagesPerRound, 
                            CONFIG_OPTIONS[configIndex] + " - Messages per Round", 
                            "Number of Processors", "Messages per Round");
                    break;
            }
            
            saveImageButton.setEnabled(true);
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading data: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Saves the current plot as a PNG image
     */
    private void savePlotAsImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Plot as PNG");
        fileChooser.setFileFilter(new FileNameExtensionFilter("PNG Images", "png"));
        
        // Set default filename based on current selection
        String configName = (String) configComboBox.getSelectedItem();
        String metricName = (String) metricComboBox.getSelectedItem();
        configName = configName.toLowerCase().replace(" ", "_");
        metricName = metricName.toLowerCase().replace(" ", "_");
        
        fileChooser.setSelectedFile(new File(configName + "_" + metricName + ".png"));
        
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".png")) {
                file = new File(file.getAbsolutePath() + ".png");
            }
            
            // Confirm overwrite if file exists
            if (file.exists()) {
                int result = JOptionPane.showConfirmDialog(this, 
                        "File exists. Overwrite?", "Confirm Overwrite", 
                        JOptionPane.YES_NO_OPTION);
                if (result != JOptionPane.YES_OPTION) {
                    return;
                }
            }
            
            // Create image from plot panel
            BufferedImage image = new BufferedImage(
                    plotPanel.getWidth(), 
                    plotPanel.getHeight(), 
                    BufferedImage.TYPE_INT_RGB);
            
            Graphics2D g2d = image.createGraphics();
            plotPanel.paintComponent(g2d);
            g2d.dispose();
            
            try {
                ImageIO.write(image, "png", file);
                JOptionPane.showMessageDialog(this, 
                        "Plot saved successfully to:\n" + file.getAbsolutePath(), 
                        "Save Successful", 
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, 
                        "Error saving image: " + e.getMessage(), 
                        "Save Error", 
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Panel for drawing the plot
     */
    private class PlotPanel extends JPanel {
        private List<Integer> xValues;
        private List<? extends Number> hs1Values;
        private List<? extends Number> lcr1Values;
        private String title;
        private String xAxisLabel;
        private String yAxisLabel;
        private boolean isDoubleData = false;
        
        public PlotPanel() {
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createLineBorder(Color.BLACK));
            setPreferredSize(new Dimension(800, 600));
            xValues = new ArrayList<>();
            hs1Values = new ArrayList<Integer>();
            lcr1Values = new ArrayList<Integer>();
        }
        
        public void updateData(List<Integer> x, List<Integer> hs, List<Integer> lcr, 
                String title, String xAxisLabel, String yAxisLabel) {
            this.xValues = x;
            this.hs1Values = hs;
            this.lcr1Values = lcr;
            this.title = title;
            this.xAxisLabel = xAxisLabel;
            this.yAxisLabel = yAxisLabel;
            this.isDoubleData = false;
            repaint();
        }
        
        public void updateDoubleData(List<Integer> x, List<Double> hs, List<Double> lcr, 
                String title, String xAxisLabel, String yAxisLabel) {
            this.xValues = x;
            this.hs1Values = hs;
            this.lcr1Values = lcr;
            this.title = title;
            this.xAxisLabel = xAxisLabel;
            this.yAxisLabel = yAxisLabel;
            this.isDoubleData = true;
            repaint();
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            int width = getWidth();
            int height = getHeight();
            int padding = 70;
            int labelPadding = 20;
            
            // Draw title
            g2d.setFont(new Font("Arial", Font.BOLD, 18));
            FontMetrics titleMetrics = g2d.getFontMetrics();
            Rectangle2D titleBounds = titleMetrics.getStringBounds(title, g2d);
            g2d.drawString(title, (int)(width / 2 - titleBounds.getWidth() / 2), 30);
            
            if (xValues.isEmpty()) {
                g2d.setFont(new Font("Arial", Font.PLAIN, 14));
                g2d.drawString("No data available. Run performance analysis first.", 100, height / 2);
                return;
            }
            
            // Find max values for scaling
            double maxX = 0;
            double maxY = 0;
            
            for (int x : xValues) {
                maxX = Math.max(maxX, x);
            }
            
            for (Number y : hs1Values) {
                maxY = Math.max(maxY, y.doubleValue());
            }
            
            for (Number y : lcr1Values) {
                maxY = Math.max(maxY, y.doubleValue());
            }
            
            // Add some padding to max values
            maxX = maxX * 1.1;
            maxY = maxY * 1.1;
            
            // Calculate scale factors
            double xScale = (double) (width - 2 * padding) / maxX;
            double yScale = (double) (height - 2 * padding) / maxY;
            
            // Draw axes
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(2));
            
            // x-axis
            g2d.drawLine(padding, height - padding, width - padding, height - padding);
            
            // y-axis
            g2d.drawLine(padding, height - padding, padding, padding);
            
            // Draw x-axis label
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            FontMetrics xLabelMetrics = g2d.getFontMetrics();
            Rectangle2D xLabelBounds = xLabelMetrics.getStringBounds(xAxisLabel, g2d);
            g2d.drawString(xAxisLabel, 
                    (int)(width / 2 - xLabelBounds.getWidth() / 2), 
                    height - padding + labelPadding + 20);
            
            // Draw y-axis label
            g2d.rotate(-Math.PI / 2);
            g2d.drawString(yAxisLabel, 
                    (int)(-(height / 2 + xLabelMetrics.getStringBounds(yAxisLabel, g2d).getWidth() / 2)), 
                    padding - labelPadding - 20);
            g2d.rotate(Math.PI / 2);
            
            // Draw tick marks and labels on x-axis
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            g2d.setStroke(new BasicStroke(1));
            
            // A simpler approach for nice round tick values
            // Always use multiples of 10 for tick values
            double xTickStep = 10;
            
            // Calculate how many ticks we'll need
            int numXTicks = (int)Math.ceil(maxX / xTickStep);
            
            // Draw the tick marks
            for (int i = 0; i <= numXTicks; i++) {
                double tickValue = i * xTickStep;
                int x = (int)(padding + (tickValue * xScale));
                
                // Only draw if within the plot area
                if (x <= width - padding) {
                    g2d.drawLine(x, height - padding, x, height - padding + 5);
                    
                    // Draw x tick label
                    String xLabel = String.format("%.0f", tickValue);
                    FontMetrics metrics = g2d.getFontMetrics();
                    Rectangle2D bounds = metrics.getStringBounds(xLabel, g2d);
                    g2d.drawString(xLabel, (int)(x - bounds.getWidth() / 2), height - padding + 20);
                }
            }
            
            // Draw tick marks and labels on y-axis
            // Find appropriate power of 10 for tick spacing
            int exponent = (int) Math.floor(Math.log10(maxY));
            double powerOf10 = Math.pow(10, exponent);
            
            // Use either 1, 2, or 5 times the power of 10 depending on the range
            double yTickStep;
            if (maxY < 2 * powerOf10) {
                yTickStep = powerOf10 / 5; // For smaller ranges
            } else if (maxY < 5 * powerOf10) {
                yTickStep = powerOf10 / 2; // For medium ranges
            } else {
                yTickStep = powerOf10; // For larger ranges
            }
            
            // Calculate how many ticks we'll need
            int numYTicks = (int) Math.ceil(maxY / yTickStep);
            
            for (int i = 0; i <= numYTicks; i++) {
                double tickValue = i * yTickStep;
                int y = height - padding - (int)(tickValue * yScale);
                
                // Only draw if within the plot area
                if (y >= padding) {
                    g2d.drawLine(padding, y, padding - 5, y);
                    
                    // Draw y tick label
                    String yLabel;
                    if (isDoubleData && tickValue < 10) {
                        yLabel = String.format("%.1f", tickValue);
                    } else {
                        yLabel = String.format("%.0f", tickValue);
                    }
                    
                    FontMetrics metrics = g2d.getFontMetrics();
                    Rectangle2D bounds = metrics.getStringBounds(yLabel, g2d);
                    g2d.drawString(yLabel, (int)(padding - bounds.getWidth() - 10), (int)(y + bounds.getHeight() / 2 - 5));
                }
            }
            
            // Add grid lines for better readability
            g2d.setColor(new Color(220, 220, 220));
            g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, new float[] {5.0f}, 0.0f));
            
            for (int i = 1; i <= numXTicks; i++) {
                double tickValue = i * xTickStep;
                int x = (int)(padding + (tickValue * xScale));
                if (x <= width - padding) {
                    g2d.drawLine(x, height - padding, x, padding);
                }
            }
            
            for (int i = 1; i <= numYTicks; i++) {
                double tickValue = i * yTickStep;
                int y = height - padding - (int)(tickValue * yScale);
                if (y >= padding) {
                    g2d.drawLine(padding, y, width - padding, y);
                }
            }
            
            // Draw HS algorithm line
            g2d.setColor(Color.BLUE);
            g2d.setStroke(new BasicStroke(2.5f));
            
            int[] xPoints = new int[xValues.size()];
            int[] yPoints = new int[xValues.size()];
            
            for (int i = 0; i < xValues.size(); i++) {
                xPoints[i] = (int)(padding + xValues.get(i) * xScale);
                yPoints[i] = height - padding - (int)(hs1Values.get(i).doubleValue() * yScale);
            }
            
            g2d.drawPolyline(xPoints, yPoints, xValues.size());
            
            // Add data points for HS
            for (int i = 0; i < xValues.size(); i++) {
                g2d.fillOval(xPoints[i] - 3, yPoints[i] - 3, 6, 6);
            }
            
            // Draw LCR algorithm line
            g2d.setColor(Color.RED);
            
            for (int i = 0; i < xValues.size(); i++) {
                xPoints[i] = (int)(padding + xValues.get(i) * xScale);
                yPoints[i] = height - padding - (int)(lcr1Values.get(i).doubleValue() * yScale);
            }
            
            g2d.drawPolyline(xPoints, yPoints, xValues.size());
            
            // Add data points for LCR
            for (int i = 0; i < xValues.size(); i++) {
                g2d.fillOval(xPoints[i] - 3, yPoints[i] - 3, 6, 6);
            }
            
            // Draw legend
            drawLegend(g2d, width, padding);
        }
        
        /**
         * Draws the legend for the plot
         */
        private void drawLegend(Graphics2D g2d, int width, int padding) {
            int legendX = width - padding - 180;
            int legendY = padding-60; // had to adjust the legend key colouring the curves so its not in the way
            int legendWidth = 170;
            int legendHeight = 70;
            int lineLength = 30;
            int textOffset = lineLength + 10;
            
            // Draw legend background
            g2d.setColor(new Color(240, 240, 240, 220));
            g2d.fillRect(legendX, legendY, legendWidth, legendHeight);
            g2d.setColor(Color.BLACK);
            g2d.drawRect(legendX, legendY, legendWidth, legendHeight);
            
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            int lineY = legendY + 20;
            
            // HS Algorithm
            g2d.setColor(Color.BLUE);
            g2d.setStroke(new BasicStroke(2.5f));
            g2d.drawLine(legendX + 10, lineY, legendX + 10 + lineLength, lineY);
            g2d.fillOval(legendX + 10 + lineLength/2 - 3, lineY - 3, 6, 6);
            g2d.setColor(Color.BLACK);
            g2d.drawString("HS Algorithm", legendX + 10 + textOffset, lineY + 5);
            
            // LCR Algorithm
            lineY += 20;
            g2d.setColor(Color.RED);
            g2d.setStroke(new BasicStroke(2.5f));
            g2d.drawLine(legendX + 10, lineY, legendX + 10 + lineLength, lineY);
            g2d.fillOval(legendX + 10 + lineLength/2 - 3, lineY - 3, 6, 6);
            g2d.setColor(Color.BLACK);
            g2d.drawString("LCR Algorithm", legendX + 10 + textOffset, lineY + 5);
        }
    }
    
    /**
     * Main method to run the plotter
     */
    public static void main(String[] args) {
        // Check if data directory exists
        File dataDir = new File("performance_data");
        if (!dataDir.exists() || !dataDir.isDirectory()) {
            JOptionPane.showMessageDialog(null,
                    "Performance data directory not found. Please run the performance analysis first.",
                    "Directory Not Found",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Launch application
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PerformancePlotter().setVisible(true);
            }
        });
    }
}