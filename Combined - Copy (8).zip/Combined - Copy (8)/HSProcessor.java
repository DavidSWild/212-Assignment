import java.util.ArrayList;
import java.util.List;

public class HSProcessor {
    private final int id;
    private HSProcessor next;
    private HSProcessor prev;
    private boolean isLeader = false;
    private int phase = 0;
    private boolean seenHigherId = false;
    private boolean terminated = false;
    
    //message queues for bidir ring
    private List<int[]> clockwiseMessages = new ArrayList<>();
    private List<int[]> counterclockwiseMessages = new ArrayList<>();
    
    //traci messages returned from both dirs
    private boolean receivedClockwise = false;
    private boolean receivedCounterclockwise = false;

    public HSProcessor(int id) {
        this.id = id;
    }

    //ring connections
    public void setNext(HSProcessor next) {
        this.next = next;
    }

    public void setPrev(HSProcessor prev) {
        this.prev = prev;
    }

    // getters
    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }
    
    public int getPrevId() {
        return prev != null ? prev.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }
    
    public int getPhase() {
        return phase;
    }
    
    public boolean isTerminated() {
        return terminated;
    }
    
    public void setTerminated(boolean terminated) {
        this.terminated = terminated;
    }
    
    // initialize processor
    public void initialise() {
        isLeader = false;
        phase = 0;
        clockwiseMessages.clear();
        counterclockwiseMessages.clear();
        receivedClockwise = false;
        receivedCounterclockwise = false;
        seenHigherId = false;
        terminated = false;
        
        //add initial OUT messages in both dirs with hop count = 1
        clockwiseMessages.add(new int[] {id, 0, 1});
        counterclockwiseMessages.add(new int[] {id, 0, 1});
    }
    
    // check if node has messages to send
    public boolean hasMessagesToSend() {
        return !terminated && (!clockwiseMessages.isEmpty() || !counterclockwiseMessages.isEmpty());
    }
    
    // send messages in both directions if we can
    public int sendMessages() {
        if (terminated) {
            return 0;
        }
        
        int count = 0;
        
        // send clockwise
        if (!clockwiseMessages.isEmpty()) {
            int[] msg = clockwiseMessages.remove(0);
            next.receiveCounterclockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (clockwise)%n", 
                id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], next.getId());
            count++;
        }
        
        // send counterclockwise
        if (!counterclockwiseMessages.isEmpty()) {
            int[] msg = counterclockwiseMessages.remove(0);
            prev.receiveClockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (counterclockwise)%n", 
                id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], prev.getId());
            count++;
        }
        
        return count;
    }
    
    // receive message from counterclockwise neighbor ie coming clockwise
    public void receiveClockwiseMessage(int[] message) {
        if (terminated) {
            return;
        }
        
        int[] msg = message.clone();
        processMessage(msg, true);
    }
    
    // receive message from clockwise neighbor ie coming counterclockwise
    public void receiveCounterclockwiseMessage(int[] message) {
        if (terminated) {
            return;
        }
        
        int[] msg = message.clone();
        processMessage(msg, false);
    }
    
    //handke received messages
    private void processMessage(int[] message, boolean fromClockwise) {
        int incomingId = message[0];
        int direction = message[1];  // 0 = OUT, 1 = IN
        int hopCount = message[2];
        
        System.out.printf("Processor %d received [id=%d, dir=%s, hop=%d] from %s%n", id, incomingId, (direction == 0 ? "OUT" : "IN"), hopCount, (fromClockwise ? "clockwise" : "counterclockwise"));
        
        // 1) own message comes back around || hop count = 0
        if (incomingId == id && direction == 0 && (hopCount == 0 || 
            (fromClockwise && !receivedClockwise) || (!fromClockwise && !receivedCounterclockwise))) {
            
            // mark dir where we got our own message
            if (fromClockwise) {
                receivedClockwise = true;
                System.out.println("Processor " + id + " received own message from clockwise direction");
            } else {
                receivedCounterclockwise = true;
                System.out.println("Processor " + id + " received own message from counterclockwise direction");
            }
            
            // leader check
            if (receivedClockwise && receivedCounterclockwise && !seenHigherId) {
                isLeader = true;
                terminated = true; // sleep to stop redundantness
                System.out.println("*** Processor " + id + " elected as leader (received own message from both directions) ***");
            } else if (receivedClockwise && receivedCounterclockwise) {
                // if received from both dirs but cant be leader cause its seen higher is
                advancePhase();
            }
            return;
        }
        
        //2) handle OUT messages from other processors
        if (direction == 0) {
            if (incomingId > id) {//cant be leader
                seenHigherId = true;
                
                if (hopCount > 1) {
                    if (fromClockwise) {// forward message + decremented hop count
                        clockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    } else {
                        counterclockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    }
                } else if (hopCount == 1) {// last hop switch to IN dir 4 return trip
                    if (fromClockwise) {
                        counterclockwiseMessages.add(new int[] {incomingId, 1, 1});
                    } else {
                        clockwiseMessages.add(new int[] {incomingId, 1, 1});
                    }
                }
            } else if (incomingId < id) {// discard messages from lower IDs
                System.out.println("Processor " + id + " discarded message from lower ID " + incomingId);
            } else if (incomingId == id) {

                if (fromClockwise) { //returning message after lopp
                    receivedClockwise = true;
                    System.out.println("Processor " + id + " received own returning message (clockwise)");
                } else {
                    receivedCounterclockwise = true;
                    System.out.println("Processor " + id + " received own returning message (counterclockwise)");
                }
                
                // check leader again
                if (receivedClockwise && receivedCounterclockwise && !seenHigherId) {
                    isLeader = true;
                    terminated = true; //sleep again
                    System.out.println("*** Processor " + id + " elected as leader (full circuit) ***");
                } else if (receivedClockwise && receivedCounterclockwise) {
                    advancePhase();
                }
            }
        }
        //3) handle IN messages
        else if (direction == 1) {
            if (incomingId == id) { //own message is returning
                if (fromClockwise) {
                    receivedClockwise = true;
                    System.out.println("Processor " + id + " received own IN message (clockwise)");
                } else {
                    receivedCounterclockwise = true;
                    System.out.println("Processor " + id + " received own IN message (counterclockwise)");
                }
                
                // Check if received from both dirs
                if (receivedClockwise && receivedCounterclockwise) {
                    if (!seenHigherId) {
                        isLeader = true;
                        terminated = true;
                        System.out.println("*** Processor " + id + " elected as leader (received own IN message from both directions) ***");
                    } else {
                        advancePhase();
                    }
                }
            } else { //forward another processors returning message
                if (incomingId > id) {
                    seenHigherId = true;
                }
                
                if (fromClockwise) {//forward the message toward its origin
                    counterclockwiseMessages.add(message.clone());
                } else {
                    clockwiseMessages.add(message.clone());
                }
            }
        }
    }
    
    // ddvance next phase 2^phase hop count
    private void advancePhase() {
        phase++;
        int newHopCount = (int)Math.pow(2, phase);
        
        //refresh received flags 4 new phases
        receivedClockwise = false;
        receivedCounterclockwise = false;
        
        //add new OUT messages with increased hop count
        clockwiseMessages.add(new int[] {id, 0, newHopCount});
        counterclockwiseMessages.add(new int[] {id, 0, newHopCount});
        
        System.out.println("Processor " + id + " advancing to phase " + phase + " with hop count " + newHopCount);
    }
}