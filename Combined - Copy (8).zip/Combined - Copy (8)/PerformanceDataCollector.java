import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Collects performance data for both HS and LCR algorithms across various configurations.
 * Stores results in detailed CSV files for analysis and plotting.
 */
public class PerformanceDataCollector {
    
    // init config params
    private static final int MIN_PROCESSORS = 5;
    private static final int MAX_PROCESSORS = 100;
    private static final int STEP_SIZE = 5;
    private static final int RANDOM_TRIALS = 10; //to get a good average
    
    //csv paths
    private static final String DATA_DIR = "performance_data";
    private static final String INCREASING_FILE = DATA_DIR + "/increasing_ids.csv";
    private static final String DECREASING_FILE = DATA_DIR + "/decreasing_ids.csv";
    private static final String RANDOM_FILE = DATA_DIR + "/random_ids.csv";
    private static final String RANDOM_STATS_FILE = DATA_DIR + "/random_stats.csv";
    

    //main meth  running performance data collection
    public static void collectPerformanceData() {
        try {
            System.out.println("\n========== COLLECTING PERFORMANCE DATA ==========");
            
            //make data dir
            File dataDir = new File(DATA_DIR);
            if (!dataDir.exists()) {
                dataDir.mkdir();
                System.out.println("Created '" + DATA_DIR + "' directory for output");
            }
            
            //init result files
            initializeDataFile(INCREASING_FILE);
            initializeDataFile(DECREASING_FILE);
            initializeDataFile(RANDOM_FILE);
            
            //init stats file for random configs
            try (PrintWriter writer = new PrintWriter(new FileWriter(RANDOM_STATS_FILE))) {
                writer.println("Processors,HSRounds_Avg,HSRounds_Min,HSRounds_Max,HSMessages_Avg,HSMessages_Min,HSMessages_Max," + "LCRRounds_Avg,LCRRounds_Min,LCRRounds_Max,LCRMessages_Avg,LCRMessages_Min,LCRMessages_Max");
            }
            
            //increasing order tests
            System.out.println("\nRunning tests with INCREASING order IDs...");
            runConfigurationTests(1, INCREASING_FILE);
            
            //decreasing order tests
            System.out.println("\nRunning tests with DECREASING order IDs...");
            runConfigurationTests(2, DECREASING_FILE);
            
            //random order tests
            System.out.println("\nRunning tests with RANDOM order IDs...");
            runRandomConfigurationTests();
            
            System.out.println("\nPerformance data collection completed. Results saved in '" + DATA_DIR + "' directory.");
            System.out.println("=================================================");
            
        } catch (Exception e) {
            System.err.println("Error collecting performance data: ");
        }
    }
    
    //init files with column headers
    private static void initializeDataFile(String filePath) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            writer.println("Processors,HSRounds,HSMessages,HSMessagePerRound,LCRRounds,LCRMessages,LCRMessagePerRound");
        }
    }
    
    //test id configs increasing || decreasing
    private static void runConfigurationTests(int idConfiguration, String outputFile) throws IOException {
        for (int n = MIN_PROCESSORS; n <= MAX_PROCESSORS; n += STEP_SIZE) {
            System.out.printf("Testing with %d processors... ", n);
            
             //1st generate random IDs we dont know n
            List<Integer> ids = new ArrayList<>();
            for (int i = 1; i <= n; i++) {
                ids.add(i);
            }
            
            if (idConfiguration == 2) {
                Collections.reverse(ids); //dec order
            }
            
            //run both algos to compare
            int[] hsResults = runHSAlgorithm(ids, false);
            int[] lcrResults = runLCRAlgorithm(ids, false);
            
            //calc message per round ratio because HS might lose in this case
            double hsMessagePerRound = hsResults[0] > 0 ? (double) hsResults[1] / hsResults[0] : 0;
            double lcrMessagePerRound = lcrResults[0] > 0 ? (double) lcrResults[1] / lcrResults[0] : 0;
            
            //add results into file
            try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile, true))) {
                writer.printf("%d,%d,%d,%.2f,%d,%d,%.2f%n", n, hsResults[0], hsResults[1], hsMessagePerRound, lcrResults[0], lcrResults[1], lcrMessagePerRound);
            }
            System.out.println("done :)");
        }
    }
    
    //runs tests with random ID configs with multi trials
    private static void runRandomConfigurationTests() throws IOException {
        Random random = new Random();
        
        for (int n = MIN_PROCESSORS; n <= MAX_PROCESSORS; n += STEP_SIZE) {
            System.out.printf("Testing with %d processors (random IDs, %d trials)... ", n, RANDOM_TRIALS);
            
            //init stats tracking total, min and max for each algos rounds and message
            int totalHSRounds = 0, minHSRounds = Integer.MAX_VALUE, maxHSRounds = 0;
            int totalHSMessages = 0, minHSMessages = Integer.MAX_VALUE, maxHSMessages = 0;
            int totalLCRRounds = 0, minLCRRounds = Integer.MAX_VALUE, maxLCRRounds = 0;
            int totalLCRMessages = 0, minLCRMessages = Integer.MAX_VALUE, maxLCRMessages = 0;
            
            //run multiple trials 10 4 each network size to get a solid result
            for (int trial = 0; trial < RANDOM_TRIALS; trial++) {
                //generate random ids
                List<Integer> ids = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    ids.add(random.nextInt(n * 3) + 1); //rqndom ids 1 - 3n
                }
                
                //run both algos
                int[] hsResults = runHSAlgorithm(ids, true);
                int[] lcrResults = runLCRAlgorithm(ids, true);
                
                //update stats 4 both algos
                totalHSRounds += hsResults[0];
                minHSRounds = Math.min(minHSRounds, hsResults[0]);
                maxHSRounds = Math.max(maxHSRounds, hsResults[0]);
                
                totalHSMessages += hsResults[1];
                minHSMessages = Math.min(minHSMessages, hsResults[1]);
                maxHSMessages = Math.max(maxHSMessages, hsResults[1]);
                
                totalLCRRounds += lcrResults[0];
                minLCRRounds = Math.min(minLCRRounds, lcrResults[0]);
                maxLCRRounds = Math.max(maxLCRRounds, lcrResults[0]);
                
                totalLCRMessages += lcrResults[1];
                minLCRMessages = Math.min(minLCRMessages, lcrResults[1]);
                maxLCRMessages = Math.max(maxLCRMessages, lcrResults[1]);
                
                System.out.print(".");
            }
            
            //calc averages perform metrics 4 trails for each algo
            int avgHSRounds = totalHSRounds / RANDOM_TRIALS;
            int avgHSMessages = totalHSMessages / RANDOM_TRIALS;
            int avgLCRRounds = totalLCRRounds / RANDOM_TRIALS;
            int avgLCRMessages = totalLCRMessages / RANDOM_TRIALS;
            
            //calc message per round ratio 4 performance metric
            double hsMessagePerRound = avgHSRounds > 0 ? (double) avgHSMessages / avgHSRounds : 0;
            double lcrMessagePerRound = avgLCRRounds > 0 ? (double) avgLCRMessages / avgLCRRounds : 0;
            
            //add results to random data file
            try (PrintWriter writer = new PrintWriter(new FileWriter(RANDOM_FILE, true))) {
                writer.printf("%d,%d,%d,%.2f,%d,%d,%.2f%n", n, avgHSRounds, avgHSMessages, hsMessagePerRound, avgLCRRounds, avgLCRMessages, lcrMessagePerRound);
            }
            
            // add them to stats file
            try (PrintWriter writer = new PrintWriter(new FileWriter(RANDOM_STATS_FILE, true))) {
                writer.printf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d%n", n, avgHSRounds, minHSRounds, maxHSRounds, avgHSMessages, minHSMessages, maxHSMessages, avgLCRRounds, minLCRRounds, maxLCRRounds, avgLCRMessages, minLCRMessages, maxLCRMessages);
            }
            System.out.println("done :)");
        }
    }
    
    //different use to the combined algo sim class because of minimal output 4 automatic testing
    private static int[] runHSAlgorithm(List<Integer> ids, boolean shouldShuffle) {
        List<Integer> hsIds = new ArrayList<>(ids);// make a new copy of ids lists s.t they dont get changed
        List<HSProcessor> processors = new ArrayList<>();
        
        for (int id : hsIds) {//create processors
            processors.add(new HSProcessor(id));
        }
        
        if (shouldShuffle) {//we dontr know n
            Collections.shuffle(processors);
        }
        
        for (int i = 0; i < processors.size(); i++) {//create bidir ring
            processors.get(i).setNext(processors.get((i + 1) % processors.size()));
            processors.get(i).setPrev(processors.get((i - 1 + processors.size()) % processors.size()));
        }
        
        HSAlgorithm.resetMessageCount();// refresh counters
        UnidirectionalFlooding.resetHSMessageCount();
        
        //run HS election
        int hsRounds = HSAlgorithm.simulate(processors);
        
        //get da leader
        int leaderId = -1;
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                leaderId = p.getId();
                break;
            }
        }
        
        //flood if leader found
        int hsFloodingRounds = 0;
        if (leaderId != -1) {
            hsFloodingRounds = UnidirectionalFlooding.announceLeaderHS(processors, leaderId);
        }
        
        //total rounds & messages
        int totalRounds = hsRounds + hsFloodingRounds;
        int totalMessages = HSAlgorithm.getTotalMessages() + UnidirectionalFlooding.getTotalHSFloodingMessages();
        
        return new int[] {totalRounds, totalMessages};
    }
    

    private static int[] runLCRAlgorithm(List<Integer> ids, boolean shouldShuffle) {
        List<Integer> lcrIds = new ArrayList<>(ids); // same thing here making a copy
        List<LCRProcessor> processors = new ArrayList<>();
        
        for (int id : lcrIds) {//make processors w ids
            processors.add(new LCRProcessor(id));
        }
        
        if (shouldShuffle) {// dont knwo n
            Collections.shuffle(processors);
        }
        
        for (int i = 0; i < processors.size(); i++) {//create unidir ring
            processors.get(i).setNext(processors.get((i + 1) % processors.size()));
        }
        
        LCRAlgorithm.resetMessageCount(); //refresh
        UnidirectionalFlooding.resetLCRMessageCount();
        
        int lcrRounds = LCRAlgorithm.simulate(processors); //run LCR election
        
        int lcrLeaderId = processors.get(0).getLeaderId(); //get da leader
        int lcrFloodingRounds = UnidirectionalFlooding.announceLeaderLCR(processors, lcrLeaderId); // broadcast
        
        //total rounds & messages
        int totalRounds = lcrRounds + lcrFloodingRounds;
        int totalMessages = LCRAlgorithm.getTotalLCRMessages() + UnidirectionalFlooding.getTotalLCRFloodingMessages();
        
        return new int[] {totalRounds, totalMessages}; //same return params array as before with HS
    }
}