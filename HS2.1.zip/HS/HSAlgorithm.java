import java.util.List;
import java.util.ArrayList;

public class HSAlgorithm {
    private static int totalMessages = 0;

    public static void resetMessageCount() {
        totalMessages = 0;
    }

    public static int getTotalMessages() {
        return totalMessages;
    }

    public static int simulate(List<HSProcessor> processors) {
        resetMessageCount();
        int round = 0;
        boolean changed = true;
        int leaderId = -1;
        int maxPhase = 0;
        int consecutiveNoMessageRounds = 0;
        final int MAX_NO_MESSAGE_ROUNDS = 3;

        // Print the ring topology for tracing
        System.out.println("\nRing Topology for HS Algorithm:");
        for (HSProcessor p : processors) {
            System.out.println("Processor " + p.getId() + 
                              " -> Next: Processor " + p.getNextId() + 
                              ", Prev: Processor " + p.getPrevId());
        }

        // Initialize all processors
        for (HSProcessor p : processors) {
            p.initialize();
        }

        // Algorithm execution loop
        while (changed && round < processors.size() * 5) { // Limit rounds to prevent infinite loops
            round++;
            changed = false;
            boolean messagesSent = false;
            
            // Update max phase for reporting
            for (HSProcessor p : processors) {
                if (p.getPhase() > maxPhase) {
                    maxPhase = p.getPhase();
                }
            }
            
            System.out.println("\n--- HS Election: Round " + round + " (Max Phase: " + maxPhase + ") ---");

            // Phase 1: Process all pending messages from previous round
            System.out.println("\n[Processing Messages]");
            for (HSProcessor p : processors) {
                if (p.isLeader() && leaderId == -1) {
                    leaderId = p.getId();
                    System.out.println("\n!!! LEADER ELECTED: Processor " + leaderId + " !!!");
                    changed = true;
                }
            }

            // Phase 2: Send new messages
            System.out.println("\n[Sending Messages]");
            for (HSProcessor p : processors) {
                if (p.hasMessagesToSend()) {
                    p.sendMessages();
                    totalMessages++;
                    messagesSent = true;
                    changed = true;
                }
            }
            
            // Print status after each round
            System.out.println("\nStatus after Round " + round + ":");
            for (HSProcessor p : processors) {
                System.out.printf("  Processor %d: Phase=%d, %s%n", 
                    p.getId(), 
                    p.getPhase(),
                    p.isLeader() ? "IS LEADER" : "not leader");
            }
            
            // Track consecutive rounds with no messages
            if (!messagesSent) {
                consecutiveNoMessageRounds++;
                System.out.println("No messages sent for " + consecutiveNoMessageRounds + 
                                  " consecutive rounds");
            } else {
                consecutiveNoMessageRounds = 0;
            }
            
            // Check if there have been no messages for several rounds
            if (consecutiveNoMessageRounds >= MAX_NO_MESSAGE_ROUNDS) {
                System.out.println("\nNo messages sent for " + MAX_NO_MESSAGE_ROUNDS + 
                                  " consecutive rounds. Algorithm appears to have converged.");
                
                // We don't artificially select a leader - we only check if one has been elected
                if (leaderId != -1) {
                    System.out.println("Leader has been elected: Processor " + leaderId);
                } else {
                    System.out.println("No leader has been explicitly elected through the algorithm.");
                }
                break;
            }
            
            // Break if leader is elected and no more messages
            if (leaderId != -1 && !messagesSent) {
                System.out.println("\nLeader elected and no more messages to send. Algorithm complete.");
                break;
            }
        }

        // Safety mechanism for maximum rounds - but no artificial leader selection
        if (round >= processors.size() * 5) {
            System.out.println("\nMaximum rounds (" + processors.size() * 5 + ") reached without natural termination.");
            
            // Check if any processor has elected itself as leader
            boolean anyLeader = false;
            for (HSProcessor p : processors) {
                if (p.isLeader()) {
                    leaderId = p.getId();
                    anyLeader = true;
                    System.out.println("Found leader through normal algorithm execution: Processor " + leaderId);
                    break;
                }
            }
            
            if (!anyLeader) {
                System.out.println("No leader has been elected through the normal algorithm execution.");
            }
        }

        // Print summary statistics
        System.out.println("\n=== HS Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalMessages);
        
        if (leaderId != -1) {
            System.out.println("Leader elected: Processor " + leaderId);
        } else {
            System.out.println("Leader elected: None");
        }
        
        System.out.println("Maximum phase reached: " + maxPhase);
        
        // Additional check for processors that believe they are leaders
        List<Integer> selfDeclaredLeaders = new ArrayList<>();
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                selfDeclaredLeaders.add(p.getId());
            }
        }
        
        if (selfDeclaredLeaders.size() > 0) {
            System.out.println("Processors that believe they are leaders: " + selfDeclaredLeaders);
            if (selfDeclaredLeaders.size() > 1) {
                System.out.println("WARNING: Multiple processors believe they are leaders!");
            }
        } else {
            System.out.println("No processor believes it is the leader.");
        }
        
        System.out.println("============================");

        return round;
    }
}