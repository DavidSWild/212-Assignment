import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Random;
import java.util.HashSet;

public class HSMainSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numProcessors;

        // Get user input for number of processors
        while (true) {
            try {
                System.out.print("Enter the number of processors (>= 2): ");
                numProcessors = Integer.parseInt(scanner.nextLine());

                if (numProcessors >= 2) {
                    break; // Valid input, exit loop
                } else {
                    System.out.println("Number of processors must be at least 2. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }

        // Generate unique random IDs
        Random random = new Random();
        HashSet<Integer> uniqueIds = new HashSet<>();
        List<Integer> ids = new ArrayList<>();

        while (uniqueIds.size() < numProcessors) {
            int newId = random.nextInt(1000) + 1; // Generate ID in range [1,1000]
            if (uniqueIds.add(newId)) {  // Ensures uniqueness
                ids.add(newId);
            }
        }

        System.out.println("\nGenerated Random " + numProcessors + " IDs: " + ids);

        boolean shouldShuffle = false;
        while (true) {
            System.out.println("\nSelect ID configuration:");
            System.out.println("1 - Increasing Order");
            System.out.println("2 - Decreasing Order");
            System.out.println("3 - Random Order");
            System.out.print("Enter your choice (1-3): ");

            String choice = scanner.nextLine();
            if (choice.equals("1")) {
                Collections.sort(ids); // Sort IDs in increasing order
                break;
            } else if (choice.equals("2")) {
                ids.sort(Collections.reverseOrder()); // Sort IDs in decreasing order
                break;
            } else if (choice.equals("3")) {
                Collections.shuffle(ids); // Random order
                shouldShuffle = true;
                break;
            } else {
                System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }

        // Initialize processors with random unique IDs
        List<HSProcessor> processors = new ArrayList<>();
        for (int id : ids) {
            processors.add(new HSProcessor(id));
        }

        // Only shuffle if the user selected "Random Order"
        if (shouldShuffle) {
            Collections.shuffle(processors);
        }

        // Create a bidirectional ring topology
        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
            processors.get(i).setPrev(processors.get((i - 1 + numProcessors) % numProcessors));
        }

        // Print the ring topology for tracing
        System.out.println("\nRing Topology:");
        for (HSProcessor p : processors) {
            System.out.println("Processor " + p.getId() + 
                              " -> Next: Processor " + p.getNextId() + 
                              ", Prev: Processor " + p.getPrevId());
        }

        // Run the HS leader election algorithm
        long startTime = System.currentTimeMillis();
        int hsRounds = HSAlgorithm.simulate(processors);
        long elapsedTime = System.currentTimeMillis() - startTime;

        // Find the elected leader through the algorithm's natural execution
        int leaderId = -1;
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                leaderId = p.getId();
                break;
            }
        }
        
        // Check if a leader was found
        if (leaderId == -1) {
            System.out.println("\nWARNING: No leader was elected by the HS algorithm.");
            System.out.println("The algorithm completed without successfully electing a leader.");
            System.out.println("This may indicate an issue with the algorithm implementation or");
            System.out.println("an unusual network configuration that prevented successful leader election.");
        }

        // Print final statistics
        System.out.println("\n======= Final Statistics =======");
        System.out.println("HS Algorithm:");
        System.out.println("  - Processors: " + numProcessors);
        System.out.println("  - ID Configuration: " + 
                          (configChoice(ids) == 1 ? "Increasing" : 
                           configChoice(ids) == 2 ? "Decreasing" : "Random"));
        System.out.println("  - Rounds: " + hsRounds);
        System.out.println("  - Messages: " + HSAlgorithm.getTotalMessages());
        System.out.println("  - Leader elected: Processor " + leaderId);
        System.out.println("  - Execution time: " + elapsedTime + " ms");
        System.out.println("=============================");

        scanner.close();
    }
    
    // Helper method to determine the configuration of IDs
    private static int configChoice(List<Integer> ids) {
        if (ids.size() <= 1) return 3; // Default to random for 0-1 elements
        
        boolean increasing = true;
        boolean decreasing = true;
        
        for (int i = 1; i < ids.size(); i++) {
            if (ids.get(i) <= ids.get(i-1)) {
                increasing = false;
            }
            if (ids.get(i) >= ids.get(i-1)) {
                decreasing = false;
            }
        }
        
        if (increasing) return 1;
        if (decreasing) return 2;
        return 3; // Random/mixed
    }
}