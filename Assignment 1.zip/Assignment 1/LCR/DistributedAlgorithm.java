import java.util.List;

class DistributedAlgorithm {
    public static int simulate(List<Processor> processors) {
        int round = 0;  // Count rounds
        boolean changed = true;
        int leaderId = -1;

        while (changed) {
            round++;  // Increment round counter
            changed = false;
            System.out.println("\n--- LCR Election: Round " + round + " ---");

            // Phase 1: Send messages
            for (Processor p : processors) {
                p.sendMessage();
            }

            // Phase 2: Process received messages
            for (Processor p : processors) {
                int oldMax = p.getLeaderId();
                p.processReceivedMessages();
                if (p.getLeaderId() != oldMax) {
                    changed = true;
                }
                if (p.isLeader()) {
                    leaderId = p.getLeaderId();
                }
            }

            // Stop if a leader is elected
            if (leaderId != -1) break;
        }

        //System.out.println("\nLCR Algorithm completed in " + round + " rounds.");
        return round;  // Return the number of LCR rounds
    }
}
