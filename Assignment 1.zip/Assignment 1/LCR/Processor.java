import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class Processor {
    int id;
    private int maxKnownId;
    Processor next;
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;

    public Processor(int id) {
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(Processor next) {
        this.next = next;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }

    public void sendMessage() {
        if (next != null) {
            next.pendingMessages.add(maxKnownId);
            System.out.println("Processor " + id + " sends <M>: [" + maxKnownId + "] -> Processor " + next.id);
        }
    }

    public void processReceivedMessages() {
        if (!pendingMessages.isEmpty()) {
            int receivedMax = Collections.max(pendingMessages);
            System.out.println("Processor " + id + " received <M>: " + pendingMessages);
            
            if (receivedMax > maxKnownId) {
                maxKnownId = receivedMax;
            } else if (receivedMax == id) {
                isLeader = true;
                //System.out.println("\nLeader elected: Processor " + id );
            }
        }
        pendingMessages.clear();
    }

    public boolean isLeader() {
        return isLeader;
    }

    public int getLeaderId() {
        return maxKnownId;
    }
}
