import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Random;
import java.util.HashSet;

public class MainSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numProcessors;

        while (true) {
            try {
                System.out.print("Enter the number of processors (>= 2): ");
                numProcessors = Integer.parseInt(scanner.nextLine());
                if (numProcessors >= 2) break;
                else System.out.println("Number of processors must be at least 2. Try again.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }

        Random random = new Random();
        HashSet<Integer> uniqueIds = new HashSet<>();
        List<Integer> ids = new ArrayList<>();

        while (uniqueIds.size() < numProcessors) {
            int newId = random.nextInt(1000) + 1;
            if (uniqueIds.add(newId)) ids.add(newId);
        }

        System.out.println("\nGenerated IDs: " + ids);

        List<Processor> processors = new ArrayList<>();
        for (int id : ids) {
            processors.add(new Processor(id));
        }

        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
            processors.get(i).setPrevious(processors.get((i - 1 + numProcessors) % numProcessors));
        }

        System.out.println("\nSelect algorithm:");
        System.out.println("1 - LCR");
        System.out.println("2 - HS");
        System.out.print("Enter choice: ");
        String algoChoice = scanner.nextLine();

        if (algoChoice.equals("1")) {
            DistributedAlgorithm.simulate(processors);
        } else if (algoChoice.equals("2")) {
            HSAlgorithm.simulate(processors);
        } else {
            System.out.println("Invalid choice. Exiting.");
            System.exit(1);
        }

        scanner.close();
    }
}
