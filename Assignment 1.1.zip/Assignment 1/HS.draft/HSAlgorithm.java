import java.util.List;

class HSAlgorithm {
    private static int totalHSMessages = 0;

    public static void resetMessageCount() {
        totalHSMessages = 0;
    }

    public static int getTotalHSMessages() {
        return totalHSMessages;
    }

    public static int simulate(List<Processor> processors) {
        resetMessageCount();
        int round = 0;
        boolean leaderElected = false;
        int leaderId = -1;

        for (Processor p : processors) {
            p.initHS();
        }

        while (!leaderElected) {
            round++;
            System.out.println("\n--- HS Election: Round " + round + " ---");
            leaderElected = false;

            // Send messages
            for (Processor p : processors) {
                Message cwMsg = p.getOutgoingClockwiseMessage();
                if (cwMsg != null) {
                    totalHSMessages++;
                    if (p.getNext() != null) {  
                        p.getNext().receiveClockwise(cwMsg);
                        System.out.printf("HS Message #%d: Processor %d sends %s -> Processor %d (clockwise)%n",
                                totalHSMessages, p.getId(), cwMsg, p.getNextId());
                    }
                }

                Message ccwMsg = p.getOutgoingCounterClockwiseMessage();
                if (ccwMsg != null) {
                    totalHSMessages++;
                    if (p.getPrevious() != null) {  
                        p.getPrevious().receiveCounterClockwise(ccwMsg);
                        System.out.printf("HS Message #%d: Processor %d sends %s -> Processor %d (counterclockwise)%n",
                                totalHSMessages, p.getId(), ccwMsg, p.getPreviousId());
                    }
                }
            }

            // Process messages
            for (Processor p : processors) {
                p.processReceivedHSMessages();
                if (p.isLeader()) {
                    leaderId = p.getId();
                    leaderElected = true;
                }
            }
        }

        System.out.println("\n=== HS Algorithm Summary ===");
        System.out.println("Rounds: " + round);
        System.out.println("Messages: " + totalHSMessages);
        System.out.println("Leader: Processor " + leaderId);
        return round;
    }
}
