import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class Processor {
    int id;
    private int maxKnownId;
    private Processor next;
    private Processor previous; // Counterclockwise neighbor
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;

    // HS-specific variables
    private Message outgoingClockwise;
    private Message outgoingCounterClockwise;
    private int phase = 0;
    private List<Message> incomingClockwise = new ArrayList<>();
    private List<Message> incomingCounterClockwise = new ArrayList<>();

    public Processor(int id) {
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(Processor next) {
        this.next = next;
    }

    public void setPrevious(Processor previous) {
        this.previous = previous;
    }

    // ✅ FIX: Add Getter Methods for `next` and `previous`
    public Processor getNext() {
        return next;
    }

    public Processor getPrevious() {
        return previous;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }

    public int getPreviousId() {
        return previous != null ? previous.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }

    // ================= LCR-Specific Methods =================
    public boolean hasMessageToSend() {
        return !pendingMessages.isEmpty() || maxKnownId == id;
    }

    public void sendMessage() {
        if (next != null) {
            next.pendingMessages.add(maxKnownId);
        }
    }

    public void processReceivedMessages() {
        if (!pendingMessages.isEmpty()) {
            int receivedMax = Collections.max(pendingMessages);
            System.out.println("Processor " + id + " received <M>: " + pendingMessages);
            
            if (receivedMax > maxKnownId) {
                maxKnownId = receivedMax;
            } else if (receivedMax == id) {
                isLeader = true;
            }
        }
        pendingMessages.clear();
    }

    public int getLeaderId() {
        return maxKnownId;
    }

    // ================= HS-Specific Methods =================
    public void initHS() {
        outgoingClockwise = new Message(id, "out", 1);
        outgoingCounterClockwise = new Message(id, "out", 1);
        phase = 0;
        isLeader = false;
    }

    public Message getOutgoingClockwiseMessage() {
        Message msg = outgoingClockwise;
        outgoingClockwise = null;
        return msg;
    }

    public Message getOutgoingCounterClockwiseMessage() {
        Message msg = outgoingCounterClockwise;
        outgoingCounterClockwise = null;
        return msg;
    }

    public void receiveClockwise(Message msg) {
        incomingClockwise.add(msg);
    }

    public void receiveCounterClockwise(Message msg) {
        incomingCounterClockwise.add(msg);
    }

    public void processReceivedHSMessages() {
        for (Message msg : incomingClockwise) {
            processHSMessage(msg, true);
        }
        for (Message msg : incomingCounterClockwise) {
            processHSMessage(msg, false);
        }
        incomingClockwise.clear();
        incomingCounterClockwise.clear();
    }

    private void processHSMessage(Message msg, boolean fromClockwise) {
        if (msg.direction.equals("out")) {
            if (msg.id > this.id) {
                if (msg.hopCount > 1) {
                    Message forward = new Message(msg.id, "out", msg.hopCount - 1);
                    if (fromClockwise) outgoingCounterClockwise = forward;
                    else outgoingClockwise = forward;
                } else if (msg.hopCount == 1) {
                    Message inMsg = new Message(msg.id, "in", 1);
                    if (fromClockwise) outgoingCounterClockwise = inMsg;
                    else outgoingClockwise = inMsg;
                }
            } else if (msg.id == this.id) {
                isLeader = true;
            }
        } else if (msg.direction.equals("in")) {
            if (msg.id == this.id) {
                phase++;
                outgoingClockwise = new Message(id, "out", (int) Math.pow(2, phase));
                outgoingCounterClockwise = new Message(id, "out", (int) Math.pow(2, phase));
            } else {
                Message forward = new Message(msg.id, "in", 1);
                if (fromClockwise) outgoingCounterClockwise = forward;
                else outgoingClockwise = forward;
            }
        }
    }
}

class Message {
    int id;
    String direction;
    int hopCount;

    public Message(int id, String direction, int hopCount) {
        this.id = id;
        this.direction = direction;
        this.hopCount = hopCount;
    }

    @Override
    public String toString() {
        return String.format("<%d, %s, %d>", id, direction, hopCount);
    }
}
