import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class Processor {
    int id;
    private int maxKnownId;
    Processor next;
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;
    private boolean active = true;
    private int phase = 0;
    private boolean sentOutward = false;
    private boolean sentInward = false;

    public Processor(int id) {
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(Processor next) {
        this.next = next;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }

    public boolean hasMessageToSend() {
        return true;
    }

    public void sendMessage() {
        if (next != null) {
            next.pendingMessages.add(maxKnownId);
        }
    }

    public void processReceivedMessages() {
        if (!pendingMessages.isEmpty()) {
            int receivedMax = Collections.max(pendingMessages);
            System.out.println("Processor " + id + " received <M>: " + pendingMessages);
            
            if (receivedMax > maxKnownId) {
                maxKnownId = receivedMax;
            } else if (receivedMax == id) {
                isLeader = true;
                active = false;
            }
        }
        pendingMessages.clear();
    }

    public boolean isLeader() {
        return isLeader;
    }

    public int getLeaderId() {
        return maxKnownId;
    }

    // HS Algorithm Support
    public void initHS() {
        phase = 0;
        sentOutward = false;
        sentInward = false;
        active = true;
    }

    public boolean hasHSMessageToSend() {
        return active && (!sentOutward || !sentInward);
    }

    public void sendHSMessage() {
        if (!sentOutward && next != null) {
            System.out.println("Processor " + id + " sends OUT message to " + next.getId() + " with hops " + (int) Math.pow(2, phase));
            next.receiveHSMessage(id, "out", (int) Math.pow(2, phase));
            sentOutward = true;
        }
        if (!sentInward && next != null) {
            System.out.println("Processor " + id + " sends IN message to " + next.getId() + " with hops " + (int) Math.pow(2, phase));
            next.receiveHSMessage(id, "in", (int) Math.pow(2, phase));
            sentInward = true;
        }
    }

    public void receiveHSMessage(int senderId, String direction, int hops) {
        if (!active) return; // Stop processing if leader is already found
        
        // Discard message if it's from a lower ID than current processor
        if (senderId < id && direction.equals("out")) {
            System.out.println("Processor " + id + " discards OUT message from " + senderId + " due to lower ID");
            return;
        }
        
        System.out.println("Processor " + id + " received " + direction.toUpperCase() + " message from " + senderId + " with hops " + hops);
        
        if (hops > 1) {
            next.receiveHSMessage(senderId, direction, hops - 1);
        } else if (hops == 1) {
            if (direction.equals("out")) {
                next.receiveHSMessage(senderId, "in", 1);
            } else if (senderId == id) {
                isLeader = true;
                active = false;
                System.out.println("Processor " + id + " is the leader!");
            }
        }
    }

    public boolean processHSReceivedMessages() {
        if (isLeader) {
            return true;
        }
        phase++;
        sentOutward = false;
        sentInward = false;
        return false;
    }
}
