import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Random;
import java.util.HashSet;

public class CombinedAlgorithmSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Choose which algorithm(s) to run
        int algorithmChoice = getAlgorithmChoice(scanner);
        
        // Get shared configuration for both algorithms
        int numProcessors = getProcessorCount(scanner);
        List<Integer> ids = generateRandomIds(numProcessors);
        System.out.println("\nGenerated Random " + numProcessors + " IDs: " + ids);
        
        int idConfiguration = getIdConfiguration(scanner, ids);
        boolean shouldShuffle = (idConfiguration == 3);
        
        // Create and display shared ring topology if both algorithms are selected
        if (algorithmChoice == 3) {
            List<Integer> topologyIds = new ArrayList<>(ids);
            List<HSProcessor> sharedTopology = new ArrayList<>();
            
            for (int id : topologyIds) {
                sharedTopology.add(new HSProcessor(id));
            }
            
            if (shouldShuffle) {
                Collections.shuffle(sharedTopology);
            }
            
            for (int i = 0; i < numProcessors; i++) {
                sharedTopology.get(i).setNext(sharedTopology.get((i + 1) % numProcessors));
                sharedTopology.get(i).setPrev(sharedTopology.get((i - 1 + numProcessors) % numProcessors));
            }
            
            System.out.println("\n============ SHARED RING TOPOLOGY ============");
            System.out.println("\nRing Topology (used by both algorithms):");
            for (HSProcessor p : sharedTopology) {
                System.out.println("Processor " + p.getId() + 
                                  " -> Next: Processor " + p.getNextId() + 
                                  ", Prev: Processor " + p.getPrevId());
            }
        }
        
        // Create shared ring configuration
        if (algorithmChoice == 1 || algorithmChoice == 3) {
            System.out.println("\n============ HS ALGORITHM SIMULATION ============");
            runHSAlgorithm(numProcessors, ids, shouldShuffle, idConfiguration, algorithmChoice == 3);
        }
        
        if (algorithmChoice == 2 || algorithmChoice == 3) {
            System.out.println("\n============ LCR ALGORITHM SIMULATION ============");
            runLCRAlgorithm(numProcessors, ids, shouldShuffle, idConfiguration, algorithmChoice == 3);
        }
        
        System.out.println("\nSimulation(s) completed.");
        scanner.close();
    }
    
    private static int getAlgorithmChoice(Scanner scanner) {
        int choice = 0;
        while (choice < 1 || choice > 3) {
            System.out.println("Choose which algorithm(s) to run:");
            System.out.println("1 - Hirschberg-Sinclair (HS) Algorithm");
            System.out.println("2 - LeLann-Chang-Roberts (LCR) Algorithm");
            System.out.println("3 - Both Algorithms (using the same ring configuration)");
            System.out.print("Enter your choice (1-3): ");
            
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice < 1 || choice > 3) {
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return choice;
    }
    
    private static void runHSAlgorithm(int numProcessors, List<Integer> ids, boolean shouldShuffle, 
                                     int idConfiguration, boolean skipTopologyPrint) {
        // Create a copy of IDs to avoid modifying the original list
        List<Integer> hsIds = new ArrayList<>(ids);
        
        // Initialize processors with IDs
        List<HSProcessor> processors = new ArrayList<>();
        for (int id : hsIds) {
            processors.add(new HSProcessor(id));
        }
        
        // Only shuffle if the user selected "Random Order"
        if (shouldShuffle) {
            Collections.shuffle(processors);
        }
        
        // Create a bidirectional ring topology
        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
            processors.get(i).setPrev(processors.get((i - 1 + numProcessors) % numProcessors));
        }
        
        // Print the ring topology for tracing only if not showing shared topology
        if (!skipTopologyPrint) {
            System.out.println("\nRing Topology for HS Algorithm:");
            for (HSProcessor p : processors) {
                System.out.println("Processor " + p.getId() + 
                                " -> Next: Processor " + p.getNextId() + 
                                ", Prev: Processor " + p.getPrevId());
            }
        }
        
        // Run the HS leader election algorithm
        System.out.println("\n== Starting HS Leader Election Algorithm ==");
        long startTime = System.currentTimeMillis();
        int hsRounds = HSAlgorithm.simulate(processors);
        long electionTime = System.currentTimeMillis() - startTime;
        
        // Find the elected leader through the algorithm's natural execution
        int leaderId = -1;
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                leaderId = p.getId();
                break;
            }
        }
        
        // Check if a leader was found
        if (leaderId == -1) {
            System.out.println("\nWARNING: No leader was elected by the HS algorithm.");
            System.out.println("The algorithm completed without successfully electing a leader.");
            System.out.println("This may indicate an issue with the algorithm implementation or");
            System.out.println("an unusual network configuration that prevented successful leader election.");
            
            // Print statistics without flooding phase
            System.out.println("\n======= HS Algorithm Final Statistics =======");
            System.out.println("HS Algorithm:");
            System.out.println("  - Processors: " + numProcessors);
            System.out.println("  - ID Configuration: " + 
                            (idConfiguration == 1 ? "Increasing" : 
                            idConfiguration == 2 ? "Decreasing" : "Random"));
            System.out.println("  - Rounds: " + hsRounds);
            System.out.println("  - Messages: " + HSAlgorithm.getTotalMessages());
            System.out.println("  - Leader elected: None");
            System.out.println("  - Execution time: " + electionTime + " ms");
            System.out.println("============================================");
            return;
        }
        
        // Run leader announcement via flooding
        System.out.println("\n== Starting Leader Announcement via Flooding (HS) ==");
        startTime = System.currentTimeMillis();
        int floodingRounds = UnidirectionalFlooding.announceLeaderHS(processors, leaderId);
        long floodingTime = System.currentTimeMillis() - startTime;
        
        // Print final statistics
        System.out.println("\n======= HS Algorithm Final Statistics =======");
        System.out.println("HS Algorithm:");
        System.out.println("  - Processors: " + numProcessors);
        System.out.println("  - ID Configuration: " + 
                        (idConfiguration == 1 ? "Increasing" : 
                        idConfiguration == 2 ? "Decreasing" : "Random"));
        System.out.println("  - Rounds: " + hsRounds);
        System.out.println("  - Messages: " + HSAlgorithm.getTotalMessages());
        System.out.println("  - Leader elected: Processor " + leaderId);
        System.out.println("  - Execution time: " + electionTime + " ms");
        
        System.out.println("\nFlooding Algorithm (HS):");
        System.out.println("  - Rounds: " + floodingRounds);
        System.out.println("  - Messages: " + UnidirectionalFlooding.getTotalHSFloodingMessages());
        System.out.println("  - Execution time: " + floodingTime + " ms");
        
        int totalRounds = hsRounds + floodingRounds;
        int totalMessages = HSAlgorithm.getTotalMessages() + UnidirectionalFlooding.getTotalHSFloodingMessages();
        long totalTime = electionTime + floodingTime;
        
        System.out.println("\nTotal (HS + Flooding):");
        System.out.println("  - Rounds: " + totalRounds);
        System.out.println("  - Messages: " + totalMessages);
        System.out.println("  - Execution time: " + totalTime + " ms");
        System.out.println("============================================");
    }
    
    private static void runLCRAlgorithm(int numProcessors, List<Integer> ids, boolean shouldShuffle, 
                                      int idConfiguration, boolean skipTopologyPrint) {
        // Create a copy of IDs to avoid modifying the original list
        List<Integer> lcrIds = new ArrayList<>(ids);
        
        // Initialize processors with IDs
        List<LCRProcessor> processors = new ArrayList<>();
        for (int id : lcrIds) {
            processors.add(new LCRProcessor(id));
        }
        
        // Only shuffle if the user selected "Random Order"
        if (shouldShuffle) {
            Collections.shuffle(processors);
        }
        
        // Create a ring topology
        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
        }
        
        // Print the ring topology for tracing only if not showing shared topology
        if (!skipTopologyPrint) {
            System.out.println("\nRing Topology for LCR Algorithm:");
            for (LCRProcessor p : processors) {
                System.out.println("Processor " + p.getId() + " -> Next: Processor " + p.getNextId());
            }
        }
        
        // Run the LCR leader election algorithm
        System.out.println("\n== Starting LCR Leader Election Algorithm ==");
        long startTime = System.currentTimeMillis();
        int lcrRounds = LCRAlgorithm.simulate(processors);
        long electionTime = System.currentTimeMillis() - startTime;
        
        int leaderId = processors.get(0).getLeaderId();
        
        // Run leader announcement via flooding
        System.out.println("\n== Starting Leader Announcement via Flooding (LCR) ==");
        startTime = System.currentTimeMillis();
        int floodingRounds = UnidirectionalFlooding.announceLeaderLCR(processors, leaderId);
        long floodingTime = System.currentTimeMillis() - startTime;
        
        // Print final statistics
        System.out.println("\n======= LCR Algorithm Final Statistics =======");
        System.out.println("LCR Algorithm:");
        System.out.println("  - Processors: " + numProcessors);
        System.out.println("  - ID Configuration: " + 
                        (idConfiguration == 1 ? "Increasing" : 
                        idConfiguration == 2 ? "Decreasing" : "Random"));
        System.out.println("  - Rounds: " + lcrRounds);
        System.out.println("  - Messages: " + LCRAlgorithm.getTotalLCRMessages());
        System.out.println("  - Leader elected: Processor " + leaderId);
        System.out.println("  - Execution time: " + electionTime + " ms");
        
        System.out.println("\nFlooding Algorithm (LCR):");
        System.out.println("  - Rounds: " + floodingRounds);
        System.out.println("  - Messages: " + UnidirectionalFlooding.getTotalLCRFloodingMessages());
        System.out.println("  - Execution time: " + floodingTime + " ms");
        
        int totalRounds = lcrRounds + floodingRounds;
        int totalMessages = LCRAlgorithm.getTotalLCRMessages() + 
                            UnidirectionalFlooding.getTotalLCRFloodingMessages();
        long totalTime = electionTime + floodingTime;
        
        System.out.println("\nTotal (LCR + Flooding):");
        System.out.println("  - Rounds: " + totalRounds);
        System.out.println("  - Messages: " + totalMessages);
        System.out.println("  - Execution time: " + totalTime + " ms");
        System.out.println("============================================");
    }
    
    private static int getProcessorCount(Scanner scanner) {
        int numProcessors = 0;
        while (numProcessors < 2) {
            try {
                System.out.print("Enter the number of processors (>= 2): ");
                numProcessors = Integer.parseInt(scanner.nextLine());
                
                if (numProcessors < 2) {
                    System.out.println("Number of processors must be at least 2. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }
        return numProcessors;
    }
    
    private static List<Integer> generateRandomIds(int numProcessors) {
        Random random = new Random();
        HashSet<Integer> uniqueIds = new HashSet<>();
        List<Integer> ids = new ArrayList<>();
        
        while (uniqueIds.size() < numProcessors) {
            int newId = random.nextInt(1000) + 1; // Generate ID in range [1,1000]
            if (uniqueIds.add(newId)) {  // Ensures uniqueness
                ids.add(newId);
            }
        }
        
        return ids;
    }
    
    private static int getIdConfiguration(Scanner scanner, List<Integer> ids) {
        int choice = 0;
        while (choice < 1 || choice > 3) {
            System.out.println("\nSelect ID configuration:");
            System.out.println("1 - Increasing Order");
            System.out.println("2 - Decreasing Order");
            System.out.println("3 - Random Order");
            System.out.print("Enter your choice (1-3): ");
            
            String input = scanner.nextLine();
            if (input.equals("1")) {
                Collections.sort(ids); // Sort IDs in increasing order
                choice = 1;
            } else if (input.equals("2")) {
                ids.sort(Collections.reverseOrder()); // Sort IDs in decreasing order
                choice = 2;
            } else if (input.equals("3")) {
                Collections.shuffle(ids); // Random order
                choice = 3;
            } else {
                System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
        return choice;
    }
}