import java.util.ArrayList;
import java.util.List;

public class HSProcessor {
    private final int id;
    private HSProcessor next;
    private HSProcessor prev;
    private boolean isLeader = false;
    private int phase = 0;
    private boolean seenHigherId = false;  // New flag to track if higher ID was seen
    private boolean terminated = false;    // Added for termination
    
    // Message structure: [id, direction, hop count]
    // Direction: 0 = outgoing, 1 = incoming
    private List<int[]> clockwiseMessages = new ArrayList<>();
    private List<int[]> counterclockwiseMessages = new ArrayList<>();
    
    // Track if both directions have returned for current phase
    private boolean receivedClockwise = false;
    private boolean receivedCounterclockwise = false;

    public HSProcessor(int id) {
        this.id = id;
    }

    public void setNext(HSProcessor next) {
        this.next = next;
    }

    public void setPrev(HSProcessor prev) {
        this.prev = prev;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }
    
    public int getPrevId() {
        return prev != null ? prev.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }
    
    public int getPhase() {
        return phase;
    }
    
    // Add methods for termination
    public boolean isTerminated() {
        return terminated;
    }
    
    public void setTerminated(boolean terminated) {
        this.terminated = terminated;
    }
    
    // Initialize processor for a new HS algorithm run
    public void initialize() {
        isLeader = false;
        phase = 0;
        clockwiseMessages.clear();
        counterclockwiseMessages.clear();
        receivedClockwise = false;
        receivedCounterclockwise = false;
        seenHigherId = false;  // Reset the higher ID flag
        terminated = false;    // Reset termination status
        
        // Add initial outgoing messages in both directions
        // Format: [id, direction, hop count]
        clockwiseMessages.add(new int[] {id, 0, 1});         // Outgoing message clockwise
        counterclockwiseMessages.add(new int[] {id, 0, 1});  // Outgoing message counterclockwise
    }
    
    // Check if processor has messages to send in either direction
    public boolean hasMessagesToSend() {
        return !terminated && (!clockwiseMessages.isEmpty() || !counterclockwiseMessages.isEmpty());
    }
    
    // Send messages in both directions if available
    public void sendMessages() {
        // Don't send messages if terminated
        if (terminated) {
            return;
        }
        
        // Send clockwise
        if (!clockwiseMessages.isEmpty()) {
            int[] msg = clockwiseMessages.remove(0);
            next.receiveCounterclockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (clockwise)%n", 
                id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], next.getId());
        }
        
        // Send counterclockwise
        if (!counterclockwiseMessages.isEmpty()) {
            int[] msg = counterclockwiseMessages.remove(0);
            prev.receiveClockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (counterclockwise)%n", 
                id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], prev.getId());
        }
    }
    
    // Receive message from counterclockwise neighbor (coming clockwise)
    public void receiveClockwiseMessage(int[] message) {
        // Don't process messages if terminated
        if (terminated) {
            return;
        }
        
        // Clone the array to avoid shared references
        int[] msg = message.clone();
        processMessage(msg, true);
    }
    
    // Receive message from clockwise neighbor (coming counterclockwise)
    public void receiveCounterclockwiseMessage(int[] message) {
        // Don't process messages if terminated
        if (terminated) {
            return;
        }
        
        // Clone the array to avoid shared references
        int[] msg = message.clone();
        processMessage(msg, false);
    }
    
    // Process incoming messages
    private void processMessage(int[] message, boolean fromClockwise) {
        int incomingId = message[0];
        int direction = message[1];  // 0 = outgoing, 1 = incoming
        int hopCount = message[2];
        
        System.out.printf("Processor %d received [id=%d, dir=%s, hop=%d] from %s%n", 
            id, incomingId, (direction == 0 ? "OUT" : "IN"), hopCount, 
            (fromClockwise ? "clockwise" : "counterclockwise"));
        
        // Case 1: I received my own outgoing message
        if (incomingId == id && direction == 0) {
            // Record that we received our message from this direction
            if (fromClockwise) {
                receivedClockwise = true;
            } else {
                receivedCounterclockwise = true;
            }
            
            // Only declare leader if we've received from BOTH directions AND never seen a higher ID
            if (receivedClockwise && receivedCounterclockwise && !seenHigherId) {
                isLeader = true;
                System.out.println("*** Processor " + id + " elected as leader (received own outgoing message from both directions) ***");
            }
            return;
        }
        
        // Case 2: Processing outgoing messages from other processors
        if (direction == 0) {
            if (incomingId > id) {
                // Mark that we've seen a higher ID
                seenHigherId = true;
                
                // Forward higher ID messages
                if (hopCount > 1) {
                    // Decrement hop count and forward
                    if (fromClockwise) {
                        // Forward in clockwise direction
                        clockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    } else {
                        // Forward in counterclockwise direction
                        counterclockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    }
                } else if (hopCount == 1) {
                    // Change direction to incoming and send back
                    if (fromClockwise) {
                        // Return in counterclockwise direction
                        counterclockwiseMessages.add(new int[] {incomingId, 1, 1});
                    } else {
                        // Return in clockwise direction
                        clockwiseMessages.add(new int[] {incomingId, 1, 1});
                    }
                }
            } else if (incomingId < id) {
                // Drop the message from lower ID processor
                System.out.println("Processor " + id + " dropped message from lower ID " + incomingId);
            }
        }
        // Case 3: Processing incoming (return) messages
        else if (direction == 1) {
            if (incomingId == id) {
                // My own message returned
                if (fromClockwise) {
                    receivedClockwise = true;
                } else {
                    receivedCounterclockwise = true;
                }
                
                // If both directions have returned, advance to next phase
                if (receivedClockwise && receivedCounterclockwise) {
                    advancePhase();
                }
            } else {
                // If we see a higher ID even in an incoming message, mark it
                if (incomingId > id) {
                    seenHigherId = true;
                }
                
                // Forward return messages from other processors
                if (fromClockwise) {
                    // Forward in counterclockwise direction
                    counterclockwiseMessages.add(message.clone());
                } else {
                    // Forward in clockwise direction
                    clockwiseMessages.add(message.clone());
                }
            }
        }
    }
    
    // Advance to next phase with doubled hop count
    private void advancePhase() {
        phase++;
        int newHopCount = (int)Math.pow(2, phase);
        
        // Reset flags
        receivedClockwise = false;
        receivedCounterclockwise = false;
        
        // Create new outgoing messages with increased hop count
        clockwiseMessages.add(new int[] {id, 0, newHopCount});
        counterclockwiseMessages.add(new int[] {id, 0, newHopCount});
        
        System.out.println("Processor " + id + " advancing to phase " + phase + 
                          " with hop count " + newHopCount);
    }
}