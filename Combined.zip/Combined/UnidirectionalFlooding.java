import java.util.List;
import java.util.Arrays;

public class UnidirectionalFlooding {
    private static int totalHSFloodingMessages = 0;   // Counter for HS flooding messages
    private static int totalLCRFloodingMessages = 0;  // Counter for LCR flooding messages

    // Reset message counters
    public static void resetHSMessageCount() {
        totalHSFloodingMessages = 0;
    }
    
    public static void resetLCRMessageCount() {
        totalLCRFloodingMessages = 0;
    }
    
    // Get message counts
    public static int getTotalHSFloodingMessages() {
        return totalHSFloodingMessages;
    }
    
    public static int getTotalLCRFloodingMessages() {
        return totalLCRFloodingMessages;
    }
    
    // Generic method for HSProcessor
    public static int announceLeaderHS(List<HSProcessor> processors, int leaderId) {
        resetHSMessageCount();
        return announceLeaderGeneric(processors, leaderId, true);
    }
    
    // Generic method for LCRProcessor
    public static int announceLeaderLCR(List<LCRProcessor> processors, int leaderId) {
        resetLCRMessageCount();
        return announceLeaderGeneric(processors, leaderId, false);
    }
    
    // Generic implementation that works with either processor type
    private static <T> int announceLeaderGeneric(List<T> processors, int leaderId, boolean isHS) {
        boolean[] received = new boolean[processors.size()];
        int round = 0;
        
        // Find the leader index
        int leaderIndex = -1;
        for (int i = 0; i < processors.size(); i++) {
            int processorId = getProcessorId(processors.get(i));
            if (processorId == leaderId) {
                leaderIndex = i;
                break;
            }
        }
        
        if (leaderIndex == -1) {
            System.out.println("Error: Leader not found in processor list.");
            return 0;
        }
        
        String algorithmType = isHS ? "HS" : "LCR";
        System.out.println("\n--- " + algorithmType + " Flooding: Round 0 ---");
        received[leaderIndex] = true;
        
        // Terminate the leader
        setTerminated(processors.get(leaderIndex), true);
        System.out.println("Processor " + leaderId + " announces itself as leader and terminates.");
        
        int remainingNodes = processors.size() - 1;
        boolean[] processed = new boolean[processors.size()];
        
        while (remainingNodes > 0) {
            round++;
            System.out.println("\n--- " + algorithmType + " Flooding: Round " + round + " ---");
            
            boolean anySent = false;
            boolean[] newReceived = Arrays.copyOf(received, received.length);
            
            for (int i = 0; i < processors.size(); i++) {
                if (received[i] && !processed[i]) {
                    int nextIndex = (i + 1) % processors.size();
                    
                    if (!received[nextIndex]) {
                        newReceived[nextIndex] = true;
                        
                        // Increment appropriate message counter
                        if (isHS) {
                            totalHSFloodingMessages++;
                        } else {
                            totalLCRFloodingMessages++;
                        }
                        
                        // Terminate the processor
                        setTerminated(processors.get(nextIndex), true);
                        
                        int currentMessageCount = isHS ? totalHSFloodingMessages : totalLCRFloodingMessages;
                        int nextProcessorId = getProcessorId(processors.get(nextIndex));
                        
                        System.out.println("Processor " + nextProcessorId + 
                            " acknowledges leader " + leaderId + " and terminates " +
                            "(Message #" + currentMessageCount + ")");
                        
                        anySent = true;
                        remainingNodes--;
                    }
                    processed[i] = true;
                }
            }
            
            received = newReceived;
            if (!anySent) break;
        }
        
        // Print termination status
        System.out.println("\nTermination Status after Flooding:");
        for (int i = 0; i < processors.size(); i++) {
            T processor = processors.get(i);
            System.out.println("Processor " + getProcessorId(processor) + 
                ": " + (isTerminated(processor) ? "terminated" : "not terminated"));
        }
        
        // Print summary statistics
        System.out.println("\n=== " + algorithmType + " Flooding Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        
        int messageCount = isHS ? totalHSFloodingMessages : totalLCRFloodingMessages;
        System.out.println("Messages sent: " + messageCount);
        System.out.println("============================");
        
        return round;
    }
    
    // Helper methods to access processor properties generically
    private static int getProcessorId(Object processor) {
        if (processor instanceof HSProcessor) {
            return ((HSProcessor) processor).getId();
        } else if (processor instanceof LCRProcessor) {
            return ((LCRProcessor) processor).getId();
        }
        return -1;
    }
    
    private static boolean isTerminated(Object processor) {
        if (processor instanceof HSProcessor) {
            return ((HSProcessor) processor).isTerminated();
        } else if (processor instanceof LCRProcessor) {
            return ((LCRProcessor) processor).isTerminated();
        }
        return false;
    }
    
    private static void setTerminated(Object processor, boolean terminated) {
        if (processor instanceof HSProcessor) {
            ((HSProcessor) processor).setTerminated(terminated);
        } else if (processor instanceof LCRProcessor) {
            ((LCRProcessor) processor).setTerminated(terminated);
        }
    }
}