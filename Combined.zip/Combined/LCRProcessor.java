import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class LCRProcessor {
    int id;
    private int maxKnownId;
    LCRProcessor next;
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;
    private boolean terminated = false; // Added for termination

    public LCRProcessor(int id) {
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(LCRProcessor next) {
        this.next = next;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }

    // Add methods for termination
    public boolean isTerminated() {
        return terminated;
    }
    
    public void setTerminated(boolean terminated) {
        this.terminated = terminated;
    }

    // New method to check if processor will send a message
    public boolean hasMessageToSend() {
        return !terminated; // Won't send if terminated
    }

    public void sendMessage() {
        if (terminated) {
            return;
        }
        
        if (next != null) {
            next.pendingMessages.add(maxKnownId);
        }
    }

    public void processReceivedMessages() {
        if (terminated) {
            return;
        }
        
        if (!pendingMessages.isEmpty()) {
            int receivedMax = Collections.max(pendingMessages);
            System.out.println("Processor " + id + " received <M>: " + pendingMessages);
            
            if (receivedMax > maxKnownId) {
                maxKnownId = receivedMax;
            } else if (receivedMax == id) {
                isLeader = true;
            }
        }
        pendingMessages.clear();
    }

    public boolean isLeader() {
        return isLeader;
    }

    public int getLeaderId() {
        return maxKnownId;
    }
}