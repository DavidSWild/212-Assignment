import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Random;
import java.util.HashSet;

public class HSCompleteSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numProcessors;

        // Get user input for number of processors
        while (true) {
            try {
                System.out.print("Enter the number of processors (>= 2): ");
                numProcessors = Integer.parseInt(scanner.nextLine());

                if (numProcessors >= 2) {
                    break; // Valid input, exit loop
                } else {
                    System.out.println("Number of processors must be at least 2. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }

        // Generate unique random IDs
        Random random = new Random();
        HashSet<Integer> uniqueIds = new HashSet<>();
        List<Integer> ids = new ArrayList<>();

        while (uniqueIds.size() < numProcessors) {
            int newId = random.nextInt(1000) + 1; // Generate ID in range [1,1000]
            if (uniqueIds.add(newId)) {  // Ensures uniqueness
                ids.add(newId);
            }
        }

        System.out.println("\nGenerated Random " + numProcessors + " IDs: " + ids);

        boolean shouldShuffle = false;
        int idConfiguration = 0;
        while (true) {
            System.out.println("\nSelect ID configuration:");
            System.out.println("1 - Increasing Order");
            System.out.println("2 - Decreasing Order");
            System.out.println("3 - Random Order");
            System.out.print("Enter your choice (1-3): ");

            String choice = scanner.nextLine();
            if (choice.equals("1")) {
                Collections.sort(ids); // Sort IDs in increasing order
                idConfiguration = 1;
                break;
            } else if (choice.equals("2")) {
                ids.sort(Collections.reverseOrder()); // Sort IDs in decreasing order
                idConfiguration = 2;
                break;
            } else if (choice.equals("3")) {
                Collections.shuffle(ids); // Random order
                shouldShuffle = true;
                idConfiguration = 3;
                break;
            } else {
                System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }

        // Initialize processors with random unique IDs
        List<HSProcessor> processors = new ArrayList<>();
        for (int id : ids) {
            processors.add(new HSProcessor(id));
        }

        // Only shuffle if the user selected "Random Order"
        if (shouldShuffle) {
            Collections.shuffle(processors);
        }

        // Create a bidirectional ring topology
        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
            processors.get(i).setPrev(processors.get((i - 1 + numProcessors) % numProcessors));
        }

        // Print the ring topology for tracing
        System.out.println("\nRing Topology:");
        for (HSProcessor p : processors) {
            System.out.println("Processor " + p.getId() + 
                              " -> Next: Processor " + p.getNextId() + 
                              ", Prev: Processor " + p.getPrevId());
        }

        // Run the HS leader election algorithm
        System.out.println("\n== Starting HS Leader Election Algorithm ==");
        long startTime = System.currentTimeMillis();
        int hsRounds = HSAlgorithm.simulate(processors);
        long electionTime = System.currentTimeMillis() - startTime;

        // Find the elected leader through the algorithm's natural execution
        int leaderId = -1;
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                leaderId = p.getId();
                break;
            }
        }
        
        // Check if a leader was found
        if (leaderId == -1) {
            System.out.println("\nWARNING: No leader was elected by the HS algorithm.");
            System.out.println("The algorithm completed without successfully electing a leader.");
            System.out.println("This may indicate an issue with the algorithm implementation or");
            System.out.println("an unusual network configuration that prevented successful leader election.");
            
            // Provide information about processor IDs for debugging
            System.out.println("\nProcessor IDs in the ring:");
            for (HSProcessor p : processors) {
                System.out.println("  Processor " + p.getId());
            }
            
            // Skip flooding since there's no leader
            System.out.println("\nSkipping flooding phase since no leader was elected.");
            return;
        }

        // Run leader announcement via flooding
        System.out.println("\n== Starting Leader Announcement via Flooding ==");
        startTime = System.currentTimeMillis();
        int floodingRounds = HSUnidirectionalFlooding.announceLeader(processors, leaderId);
        long floodingTime = System.currentTimeMillis() - startTime;

        // Print final statistics
        System.out.println("\n======= Final Statistics =======");
        System.out.println("HS Algorithm:");
        System.out.println("  - Processors: " + numProcessors);
        System.out.println("  - ID Configuration: " + 
                          (idConfiguration == 1 ? "Increasing" : 
                           idConfiguration == 2 ? "Decreasing" : "Random"));
        System.out.println("  - Rounds: " + hsRounds);
        System.out.println("  - Messages: " + HSAlgorithm.getTotalMessages());
        System.out.println("  - Leader elected: Processor " + leaderId);
        System.out.println("  - Execution time: " + electionTime + " ms");
        
        System.out.println("\nFlooding Algorithm:");
        System.out.println("  - Rounds: " + floodingRounds);
        System.out.println("  - Messages: " + HSUnidirectionalFlooding.getTotalFloodingMessages());
        System.out.println("  - Execution time: " + floodingTime + " ms");
        
        int totalRounds = hsRounds + floodingRounds;
        int totalMessages = HSAlgorithm.getTotalMessages() + HSUnidirectionalFlooding.getTotalFloodingMessages();
        long totalTime = electionTime + floodingTime;
        
        System.out.println("\nTotal:");
        System.out.println("  - Rounds: " + totalRounds);
        System.out.println("  - Messages: " + totalMessages);
        System.out.println("  - Execution time: " + totalTime + " ms");
        System.out.println("=============================");

        // Theoretical comparisons
        System.out.println("\n=== Theoretical Analysis ===");
        int theoreticalHSRounds = (int)(Math.log(numProcessors) / Math.log(2)) * 2 + 1; // log₂n phases, each taking 2 rounds + 1
        int theoreticalHSMessages = numProcessors * theoreticalHSRounds * 2; // very rough approximation
        System.out.println("HS theoretical rounds: ~" + theoreticalHSRounds + " (depends on network configuration)");
        System.out.println("HS theoretical messages: O(n log n), roughly ~" + theoreticalHSMessages);
        System.out.println("Flooding theoretical rounds: " + (numProcessors - 1) + " (for n processors in a ring)");
        System.out.println("Flooding theoretical messages: " + (numProcessors - 1) + " (for n processors in a ring)");
        System.out.println("============================");

        scanner.close();
    }
}