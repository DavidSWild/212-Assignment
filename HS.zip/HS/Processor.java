import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class Processor {
    int id;
    private int maxKnownId;
    Processor next;
    Processor prev;
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;
    private boolean active = true;
    private int phase = 0;
    private boolean sentOutward = false;
    private boolean sentInward = false;
    private int discardedMessageCount = 0;

    public Processor(int id) {
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(Processor next) {
        this.next = next;
    }
    
    public void setPrev(Processor prev) {
        this.prev = prev;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }
    
    public int getPrevId() {
        return prev != null ? prev.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }

    public int getLeaderId() {
        return maxKnownId;
    }

    // ✅ Restoring LCR-Specific Methods
    public boolean hasMessageToSend() {
        return !pendingMessages.isEmpty();
    }

    public void sendMessage() {
        if (next != null) {
            next.pendingMessages.add(maxKnownId);
        }
    }

    public void processReceivedMessages() {
        if (!pendingMessages.isEmpty()) {
            int receivedMax = Collections.max(pendingMessages);
            System.out.println("Processor " + id + " received <M>: " + pendingMessages);
            
            if (receivedMax > maxKnownId) {
                maxKnownId = receivedMax;
            } else if (receivedMax == id) {
                isLeader = true;
                active = false;
            }
        }
        pendingMessages.clear();
    }

    public void initHS() {
        phase = 0;
        sentOutward = false;
        sentInward = false;
        active = true;
        discardedMessageCount = 0;
    }

    public boolean hasHSMessageToSend() {
        return active && (!sentOutward || !sentInward);
    }

    public void sendHSMessage() {
        if (!sentOutward && next != null) {
            if (next.id > id) {
                discardedMessageCount++;
                System.out.println("Processor " + id + " discards OUT message to " + next.getId() + " due to lower ID.");
            } else {
                System.out.println("Processor " + id + " sends OUT message to " + next.getId() + " with hops " + (int) Math.pow(2, phase));
                next.receiveHSMessage(id, "out", (int) Math.pow(2, phase));
            }
            sentOutward = true;
        }
        if (!sentInward && prev != null) {
            if (prev.id > id) {
                discardedMessageCount++;
                System.out.println("Processor " + id + " discards OUT message to " + prev.getId() + " due to lower ID.");
            } else {
                System.out.println("Processor " + id + " sends OUT message to " + prev.getId() + " with hops " + (int) Math.pow(2, phase));
                prev.receiveHSMessage(id, "out", (int) Math.pow(2, phase));
            }
            sentInward = true;
        }
    }

    public void receiveHSMessage(int senderId, String direction, int hops) {
        if (!active) return; 
        System.out.println("Processor " + id + " received " + direction.toUpperCase() + " message from " + senderId + " with hops " + hops);
        
        if (hops > 1) {
            if (direction.equals("out")) {
                if (next != null) next.receiveHSMessage(senderId, direction, hops - 1);
            } else {
                if (prev != null) prev.receiveHSMessage(senderId, direction, hops - 1);
            }
        } else if (hops == 1) {
            if (direction.equals("out")) {
                if (senderId == id) {
                    isLeader = true;
                    active = false;
                    System.out.println("Processor " + id + " is the leader!");
                } else {
                    if (next != null) next.receiveHSMessage(senderId, "in", 1);
                    if (prev != null) prev.receiveHSMessage(senderId, "in", 1);
                }
            }
        }
    }

    public boolean processHSReceivedMessages() {
        if (isLeader) {
            return true;
        }
        phase++;
        sentOutward = false;
        sentInward = false;
        return false;
    }
    
    public int getDiscardedMessageCount() {
        return discardedMessageCount;
    }
}
