import java.util.List;
import java.util.ArrayList;

class HSAlgorithm {
    private static int totalHSMessages = 0;

    public static void resetMessageCount() {
        totalHSMessages = 0;
    }

    public static int getTotalHSMessages() {
        return totalHSMessages;
    }

    public static int simulate(List<Processor> processors) {
        resetMessageCount();
        int round = 0;
        boolean leaderFound = false;
        int leaderId = -1;

        // Initialize processors for HS
        for (Processor p : processors) {
            p.initHS();
        }

        while (!leaderFound) {
            round++;
            System.out.println("\n--- HS Election: Round " + round + " ---");

            // Phase 1: Send messages
            for (Processor p : processors) {
                if (p.hasHSMessageToSend()) {
                    totalHSMessages++;
                    p.sendHSMessage();
                }
            }

            // Phase 2: Process received messages
            for (Processor p : processors) {
                if (p.processHSReceivedMessages()) {
                    leaderFound = true;
                    leaderId = p.getId();
                }
            }

            if (leaderFound) break;
        }

        // Print summary statistics
        System.out.println("\n=== HS Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalHSMessages);
        System.out.println("Leader elected: Processor " + leaderId);
        System.out.println("============================");

        return round;
    }
}
