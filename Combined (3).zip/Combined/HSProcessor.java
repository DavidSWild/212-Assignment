import java.util.ArrayList;
import java.util.List; // data structure

public class HSProcessor {
    private final int id;
    private HSProcessor next; //neigbours
    private HSProcessor prev;
    private boolean isLeader = false;
    private int phase = 0;
    private boolean seenHigherId = false;
    private boolean terminated = false;
    
    // direction; 0=OUT, 1=IN
    private List<int[]> clockwiseMessages = new ArrayList<>(); // 2 lists for both direction
    private List<int[]> counterclockwiseMessages = new ArrayList<>();
    
    // track if both directions have returned for current phase
    private boolean receivedClockwise = false;//????
    private boolean receivedCounterclockwise = false;

    public HSProcessor(int id) { //cnstr method
        this.id = id;
    }
    //cring connections
    public void setNext(HSProcessor next) {
        this.next = next;
    }

    public void setPrev(HSProcessor prev) {
        this.prev = prev;
    }
    //Processor info
    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }
    
    public int getPrevId() {
        return prev != null ? prev.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }
    
    public int getPhase() {
        return phase;
    }
    
    public boolean isTerminated() {
        return terminated;
    }
    
    public void setTerminated(boolean terminated) {
        this.terminated = terminated;
    }
    
    //init P for new HS algo run
    public void initialize() {
        isLeader = false;
        phase = 0;
        clockwiseMessages.clear();
        counterclockwiseMessages.clear();
        receivedClockwise = false;
        receivedCounterclockwise = false;
        seenHigherId = false;  // fresh slate
        terminated = false;
        
        //first OUT messages in both directions
        clockwiseMessages.add(new int[] {id, 0, 1});
        counterclockwiseMessages.add(new int[] {id, 0, 1});
    }
    
    //send
    //check if P has messages to send in either direction
    public boolean hasMessagesToSend() {
        return !terminated && (!clockwiseMessages.isEmpty() || !counterclockwiseMessages.isEmpty());//??????
    }
    
    //send both directions if possible
    public int sendMessages() {
        if (terminated) {
            return 0;
        }
        
        int count = 0;
        
        // send clockwise
        if (!clockwiseMessages.isEmpty()) {
            int[] msg = clockwiseMessages.remove(0);
            next.receiveCounterclockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (clockwise)%n", id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], next.getId());
            count++;
        }
        
        // send counterclockwise
        if (!counterclockwiseMessages.isEmpty()) {
            int[] msg = counterclockwiseMessages.remove(0);
            prev.receiveClockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (counterclockwise)%n", id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], prev.getId());
            count++;
        }
        
        return count;
    }
    
    //receive
    //receive message from counterclockwise neighbor (coming clockwise)
    public void receiveClockwiseMessage(int[] message) {
        if (terminated) {// don't process messages if terminated
            return;
        }
        
        int[] msg = message.clone();//clone the array to avoid changing og list
        processMessage(msg, true);
    }
    
    //receive message from clockwise neighbor (coming counterclockwise)
    public void receiveCounterclockwiseMessage(int[] message) {
        if (terminated) {
            return;
        }
        
        int[] msg = message.clone();//clone again
        processMessage(msg, false);
    }
    
    //process IN messages
    private void processMessage(int[] message, boolean fromClockwise) {
        int incomingId = message[0];
        int direction = message[1];  //0 = OUT, 1 = IN
        int hopCount = message[2];
        
        System.out.printf("Processor %d received [id=%d, dir=%s, hop=%d] from %s%n", id, incomingId, (direction == 0 ? "OUT" : "IN"), hopCount, (fromClockwise ? "clockwise" : "counterclockwise"));
        
        //1) received own OUT message
        if (incomingId == id && direction == 0) {
            // record that we received our message from this direction
            if (fromClockwise) {
                receivedClockwise = true;
            } else {
                receivedCounterclockwise = true;
            }
            
            // only declare leader if ID received back from BOTH directions AND never seen a higher ID because of false leader problems due to simulation
            if (receivedClockwise && receivedCounterclockwise && !seenHigherId) {
                isLeader = true;
                System.out.println("*** Processor " + id + " elected as leader (received own outgoing message from both directions) ***");
            }
            return;
        }
        
        //2) processing OUT messages from others
        if (direction == 0) {
            if (incomingId > id) {
                seenHigherId = true;
                
                //forwarding higher ID messages
                if (hopCount > 1) {
                    if (fromClockwise) { //decrement hop count and forward
                        clockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    } else {
                        counterclockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    }
                } else if (hopCount == 1) { // last hop
                    if (fromClockwise) {//switch direction to IN & send back to the og
                        counterclockwiseMessages.add(new int[] {incomingId, 1, 1});
                    } else {
                        clockwiseMessages.add(new int[] {incomingId, 1, 1});
                    }
                }
            } else if (incomingId < id) {
                System.out.println("Processor " + id + " discarded message from lower ID " + incomingId);// drop the message from lower ID
            }
        }
        //3) processing IN messages
        else if (direction == 1) {
            if (incomingId == id) {
                if (fromClockwise) {// own message returned back
                    receivedClockwise = true; // marking where it came from
                } else {
                    receivedCounterclockwise = true;
                }
                
                if (receivedClockwise && receivedCounterclockwise) {//adv 2 the next pahse
                    advancePhase();
                }
            } else {// say our current p is not the biggest in the jungle
                if (incomingId > id) {
                    seenHigherId = true;
                }
                // help forward anothers higher ID back to its og
                if (fromClockwise) {
                    counterclockwiseMessages.add(message.clone());
                } else {
                    clockwiseMessages.add(message.clone());
                }
            }
        }
    }
    
    //ddvance to next phase 2^p
    private void advancePhase() {
        phase++;
        int newHopCount = (int)Math.pow(2, phase);// doubled hop
        
        //reset flags
        receivedClockwise = false;
        receivedCounterclockwise = false;
        
        //create new OUT messages with increased hop
        clockwiseMessages.add(new int[] {id, 0, newHopCount});
        counterclockwiseMessages.add(new int[] {id, 0, newHopCount});
        
        System.out.println("Processor " + id + " advancing to phase " + phase + " with hop count " + newHopCount);
    }
}