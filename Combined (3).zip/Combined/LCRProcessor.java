import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class LCRProcessor { // intit variables
    int id;
    private int maxKnownId;
    LCRProcessor next;
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;
    private boolean terminated = false;

    public LCRProcessor(int id) { //const meth to create processors
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(LCRProcessor next) { //node connections
        this.next = next;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1; //?????????
    }

    // Add methods for termination
    public boolean isTerminated() { //check if p is finised
        return terminated;
    }
    
    public void setTerminated(boolean terminated) { // check the p status
        this.terminated = terminated;
    }

    public boolean hasMessageToSend() {
        return !terminated; // wont send if p has terminated
    }

    public void sendMessage() {
        if (terminated) {
            return;
        }
        if (next != null) {
            next.pendingMessages.add(maxKnownId); //send max seen to neighbour
        }
    }

    public void processReceivedMessages() {
        if (terminated) {
            return; // do nothing if already p is terminated
        }
        
        if (!pendingMessages.isEmpty()) {
            int receivedMax = Collections.max(pendingMessages); // chhose the max from buffer
            System.out.println("Processor " + id + " received <M>: " + pendingMessages);
            //update max 
            if (receivedMax > maxKnownId) {
                maxKnownId = receivedMax;
            } else if (receivedMax == id) { // leader declr
                isLeader = true;
            }
        }
        pendingMessages.clear(); // prpare 4 next round
    }

    public boolean isLeader() { //each p asks itself if its the leader internally
        return isLeader;
    }

    public int getLeaderId() { // feeds who the local max seen to the distributed algo
        return maxKnownId;
    }
}