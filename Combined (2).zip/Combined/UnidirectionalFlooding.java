import java.util.List;
import java.util.Arrays;

public class UnidirectionalFlooding {
    private static int totalHSFloodingMessages = 0; // init counters
    private static int totalLCRFloodingMessages = 0; 

    // refresh counters
    public static void resetHSMessageCount() {
        totalHSFloodingMessages = 0;
    }
    
    public static void resetLCRMessageCount() {
        totalLCRFloodingMessages = 0;
    }
    
    // getters 4 message counts
    public static int getTotalHSFloodingMessages() {
        return totalHSFloodingMessages;
    }
    
    public static int getTotalLCRFloodingMessages() {
        return totalLCRFloodingMessages;
    }
    
    // Generic method for HSProcessor
    public static int announceLeaderHS(List<HSProcessor> processors, int leaderId) {
        resetHSMessageCount();
        return announceLeaderGeneric(processors, leaderId, true);
    }
    
    // Generic method for LCRProcessor
    public static int announceLeaderLCR(List<LCRProcessor> processors, int leaderId) {
        resetLCRMessageCount();
        return announceLeaderGeneric(processors, leaderId, false);
    }
    
    // Generic implementation that works with either processor type
    private static <T> int announceLeaderGeneric(List<T> processors, int leaderId, boolean isHS) {
        boolean[] received = new boolean[processors.size()]; // array for Ps who have heard the broadcast
        int round = 0;
        
        //find the leader index in array
        int leaderIndex = -1;
        for (int i = 0; i < processors.size(); i++) {
            int processorId = getProcessorId(processors.get(i));
            if (processorId == leaderId) {
                leaderIndex = i;
                break;
            }
        }
        // error check incase
        if (leaderIndex == -1) {
            System.out.println("Error: Leader not found in processor list.");
            return 0;
        }
        
        String algorithmType = isHS ? "HS" : "LCR";
        System.out.println("\n--- " + algorithmType + " Flooding: Round 0 ---");
        received[leaderIndex] = true; // leader has recieved the broadcast first of course
        
        //terminate the leader from the beginning
        setTerminated(processors.get(leaderIndex), true);
        System.out.println("Processor " + leaderId + " announces itself as leader and terminates.");
        
        //remaining nodes
        int remainingNodes = processors.size() - 1;
        boolean[] processed = new boolean[processors.size()]; //array for nodes who have helped spread the broadcast
        
        while (remainingNodes > 0) { // broadcast spreading for the unenlightened
            round++;
            System.out.println("\n--- " + algorithmType + " Flooding: Round " + round + " ---");
            
            boolean anySent = false; //flag tracks whether messages were sent this rounf
            boolean[] newReceived = Arrays.copyOf(received, received.length);//updatenew receivers to the array while keeping the old one
            
            for (int i = 0; i < processors.size(); i++) {
                if (received[i] && !processed[i]) { //checks if Ps have gotten the broadcast but not paased on
                    int nextIndex = (i + 1) % processors.size(); // check if neighbour has received the broadcast
                    
                    if (!received[nextIndex]) {
                        newReceived[nextIndex] = true; //pass message along to those not received yet
                        
                        //incrmnt respective counters for analysis
                        if (isHS) {
                            totalHSFloodingMessages++;
                        } else {
                            totalLCRFloodingMessages++;
                        }
                        
                        //sleeps once done
                        setTerminated(processors.get(nextIndex), true);
                        
                        int currentMessageCount = isHS ? totalHSFloodingMessages : totalLCRFloodingMessages;
                        int nextProcessorId = getProcessorId(processors.get(nextIndex));
                        
                        System.out.println("Processor " + nextProcessorId + " acknowledges leader " + leaderId + " and terminates " + "(Message #" + currentMessageCount + ")");
                        
                        anySent = true; // flags to check if messages were sent this round
                        remainingNodes--;// decrmnt remaining unenlightened nodes
                    }
                    processed[i] = true; // to not repeat broadcasting the node later on
                }
            }
            
            received = newReceived;// updates array
            if (!anySent) break;// break ealry if nothing was sent this round
        }
        
        // termination status output for each P
        System.out.println("\nTermination Status after Flooding:");
        for (int i = 0; i < processors.size(); i++) {
            T processor = processors.get(i);
            System.out.println("Processor " + getProcessorId(processor) + ": " + (isTerminated(processor) ? "terminated" : "not terminated"));
        }
        
        // print summary stats
        System.out.println("\n=== " + algorithmType + " Flooding Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        
        int messageCount = isHS ? totalHSFloodingMessages : totalLCRFloodingMessages;
        System.out.println("Messages sent: " + messageCount);
        System.out.println("============================");
        
        return round;
    }
    
    // Helper methods to access processor properties generically
    private static int getProcessorId(Object processor) {
        if (processor instanceof HSProcessor) { //check if P has terminated
            return ((HSProcessor) processor).getId();
        } else if (processor instanceof LCRProcessor) {
            return ((LCRProcessor) processor).getId();
        }
        return -1;
    }
    
    private static boolean isTerminated(Object processor) {
        if (processor instanceof HSProcessor) {
            return ((HSProcessor) processor).isTerminated();
        } else if (processor instanceof LCRProcessor) {
            return ((LCRProcessor) processor).isTerminated();
        }
        return false;
    }
    
    private static void setTerminated(Object processor, boolean terminated) {
        if (processor instanceof HSProcessor) {
            ((HSProcessor) processor).setTerminated(terminated);
        } else if (processor instanceof LCRProcessor) {
            ((LCRProcessor) processor).setTerminated(terminated);
        }
    }
}