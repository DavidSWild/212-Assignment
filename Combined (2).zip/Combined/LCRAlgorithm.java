import java.util.List;

class LCRAlgorithm {
    private static int totalLCRMessages = 0; //global messgae count 4 analysis

    public static void resetMessageCount() { //fresh slate
        totalLCRMessages = 0;
    }

    public static int getTotalLCRMessages() { 
        return totalLCRMessages;
    }

    public static int simulate(List<LCRProcessor> processors) { // main meth takes a list of processors and rtrns n of rounds 4 analysis
        resetMessageCount(); // start clean
        int round = 0;
        boolean changed = true; // flag 4 determining when to stop
        int leaderId = -1; // start invalid cuz no leader elected yet

        while (changed) { // main algo loop that goes until something changes
            round++;
            changed = false; // reset @ the start of each round
            System.out.println("\n--- LCR Election: Round " + round + " ---");

            //phase 1/2, send messages
            for (LCRProcessor p : processors) { // each p sends a message if pssosible
                if (p.hasMessageToSend()) { //terminated ps cannot send
                    totalLCRMessages++;
                    p.sendMessage();
                    System.out.printf("Message #%d: Processor %d sends <M>: [%d] -> Processor %d%n", totalLCRMessages, p.getId(), p.getLeaderId(), p.getNextId());
                }
            }

            //phase 2/2, process received messages
            for (LCRProcessor p : processors) {
                int oldMax = p.getLeaderId();// old max 4 comparison with upcoming new max maybe
                p.processReceivedMessages();
                if (p.getLeaderId() != oldMax) { //if highest id changed
                    changed = true; //our algo continues 
                }
                if (p.isLeader()) { //ask p if its the leader
                    leaderId = p.getLeaderId(); //global leader var.
                }
            }
            if (leaderId != -1) break; //end loop once valid leader has been elected
        }

        //summary
        System.out.println("\n=== LCR Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalLCRMessages);
        System.out.println("Leader elected: Processor " + leaderId);
        System.out.println("============================");

        return round;
    }
}