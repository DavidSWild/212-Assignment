import java.util.List;

class DistributedAlgorithm {
    private static int totalLCRMessages = 0;

    public static void resetMessageCount() {
        totalLCRMessages = 0;
    }

    public static int getTotalLCRMessages() {
        return totalLCRMessages;
    }

    public static int simulate(List<Processor> processors) {
        resetMessageCount();
        int round = 0;
        boolean changed = true;
        int leaderId = -1;
        boolean allTerminated = false;

        while (!allTerminated) {
            round++;
            changed = false;
            System.out.println("\n--- LCR Election: Round " + round + " ---");

            // Phase 1: Send messages
            for (Processor p : processors) {
                if (p.hasMessageToSend()) {
                    totalLCRMessages++;
                    p.sendMessage();
                    System.out.printf("Message #%d: Processor %d sends <M>: [%d] -> Processor %d%n", 
                        totalLCRMessages, p.getId(), p.getLeaderId(), p.getNextId());
                    changed = true;
                }
            }

            // Phase 2: Process received messages
            for (Processor p : processors) {
                int oldMax = p.getLeaderId();
                p.processReceivedMessages();
                if (p.getLeaderId() != oldMax) {
                    changed = true;
                }
                if (p.isLeader()) {
                    leaderId = p.getId();
                }
            }

            // If a leader is found and no messages are in transit, we can terminate
            if (leaderId != -1 && !changed) {
                // Ensure all processors know the leader
                for (Processor p : processors) {
                    if (!p.hasTerminated()) {
                        p.receiveLeaderAnnouncement(leaderId);
                    }
                }
            }

            // Check if all processors have terminated
            allTerminated = true;
            for (Processor p : processors) {
                if (!p.hasTerminated()) {
                    allTerminated = false;
                    break;
                }
            }

            // Safety check to prevent infinite loops
            if (!changed && !allTerminated && round > processors.size() * 2) {
                System.out.println("WARNING: No changes but not all processors have terminated.");
                
                // Force termination by announcing a leader (if one exists)
                if (leaderId != -1) {
                    for (Processor p : processors) {
                        if (!p.hasTerminated()) {
                            p.receiveLeaderAnnouncement(leaderId);
                        }
                    }
                    allTerminated = true;
                }
            }
        }

        // Print summary statistics
        System.out.println("\n=== LCR Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalLCRMessages);
        System.out.println("Leader elected: Processor " + leaderId);
        System.out.println("============================");

        return round;
    }
}