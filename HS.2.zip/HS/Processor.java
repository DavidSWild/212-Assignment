import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

class Processor {
    int id;
    private int maxKnownId;
    Processor next;
    Processor prev;
    private List<Integer> pendingMessages = new ArrayList<>();
    private boolean isLeader = false;
    private boolean terminated = false;
    
    // HS-specific variables
    private boolean active = true;
    private int phase = 0;
    private boolean sentOutward = false;
    private boolean sentInward = false;
    private List<Message> pendingHSMessages = new ArrayList<>();
    private int discardedMessageCount = 0;
    private int leaderId = -1;
    private boolean receivedOwnInClockwise = false;
    private boolean receivedOwnInCounterClockwise = false;

    public Processor(int id) {
        this.id = id;
        this.maxKnownId = id;
    }

    public void setNext(Processor next) {
        this.next = next;
    }
    
    public void setPrev(Processor prev) {
        this.prev = prev;
    }

    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }
    
    public int getPrevId() {
        return prev != null ? prev.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }

    public int getLeaderId() {
        return maxKnownId;
    }

    public boolean hasTerminated() {
        return terminated;
    }
    
    public void setAsLeader(int leaderID) {
        this.isLeader = true;
        this.leaderId = leaderID;
        this.maxKnownId = leaderID;
        this.terminated = true;
        System.out.println("Processor " + id + " has been set as the leader!");
    }

    // ---- LCR Algorithm Methods ----
    
    public boolean hasMessageToSend() {
        return !terminated && !pendingMessages.isEmpty();
    }

    public void sendMessage() {
        if (next != null && !pendingMessages.isEmpty()) {
            next.pendingMessages.add(maxKnownId);
        }
    }

    public void processReceivedMessages() {
        if (pendingMessages.isEmpty()) return;
        
        int receivedMax = Collections.max(pendingMessages);
        System.out.println("Processor " + id + " received <M>: " + pendingMessages);
        
        if (receivedMax > maxKnownId) {
            maxKnownId = receivedMax;
        } else if (receivedMax == id) {
            isLeader = true;
            maxKnownId = id;
            terminated = true;
            System.out.println("Processor " + id + " has been elected as leader!");
        }
        
        pendingMessages.clear();
    }

    // ---- HS Algorithm Methods ----
    
    private static class Message {
        int senderId;       // ID of the processor that originated the message
        String direction;   // "out" or "in"
        int hops;           // Number of hops the message can travel
        boolean fromNext;   // Whether message came from next processor (true) or prev processor (false)
        
        Message(int senderId, String direction, int hops, boolean fromNext) {
            this.senderId = senderId;
            this.direction = direction;
            this.hops = hops;
            this.fromNext = fromNext;
        }
        
        @Override
        public String toString() {
            return "[" + senderId + ", " + direction + ", " + hops + "]";
        }
    }
    
    public void initHS() {
        phase = 0;
        sentOutward = false;
        sentInward = false;
        active = true;
        isLeader = false;
        terminated = false;
        leaderId = -1;
        discardedMessageCount = 0;
        pendingHSMessages.clear();
        receivedOwnInClockwise = false;
        receivedOwnInCounterClockwise = false;
    }

    public boolean hasHSMessageToSend() {
        // Either we're active and need to send messages for this phase
        // or we need to forward received messages
        if (terminated) return false;
        if (!pendingHSMessages.isEmpty()) return true;
        return active && (!sentOutward);
    }

    public void sendHSMessage() {
        if (terminated) return;
        
        // First, handle forwarding of pending messages
        if (!pendingHSMessages.isEmpty()) {
            List<Message> processedMessages = new ArrayList<>(pendingHSMessages);
            pendingHSMessages.clear();
            
            for (Message msg : processedMessages) {
                forwardHSMessage(msg);
            }
            return;
        }
        
        // Then handle our own phase messages if we're still active
        if (!active) return;
        
        // Send outward messages in both directions (as per HS algorithm)
        if (!sentOutward) {
            // Send clockwise (to next)
            if (next != null) {
                int hops = (int) Math.pow(2, phase);
                System.out.println("Processor " + id + " sends OUT message [" + id + ", out, " + hops + "] to " + next.getId());
                next.receiveHSMessage(id, "out", hops, false);  // Not from next
            }
            
            // Send counterclockwise (to prev)
            if (prev != null) {
                int hops = (int) Math.pow(2, phase);
                System.out.println("Processor " + id + " sends OUT message [" + id + ", out, " + hops + "] to " + prev.getId());
                prev.receiveHSMessage(id, "out", hops, true);  // From next
            }
            
            sentOutward = true;
        }
    }

    private void forwardHSMessage(Message msg) {
        // KEY FIX: Properly handle message direction based on source
        
        if (msg.direction.equals("out")) {
            // Handle outgoing messages
            if (msg.hops > 1) {
                // 1. Message is our own - skip processing
                if (msg.senderId == id) {
                    isLeader = true;
                    leaderId = id;
                    terminated = true;
                    System.out.println("Processor " + id + " detects it's the leader (received own message with hops > 1)!");
                    return;
                }
                
                // 2. Message is from higher ID - forward along the same path
                if (msg.senderId > id) {
                    Message newMsg = new Message(msg.senderId, "out", msg.hops - 1, msg.fromNext);
                    
                    // Forward in same direction it was received
                    if (msg.fromNext) {
                        // From next, send to prev
                        System.out.println("Processor " + id + " forwards OUT message " + newMsg + " to " + prev.getId());
                        prev.receiveHSMessage(newMsg.senderId, newMsg.direction, newMsg.hops, true);
                    } else {
                        // From prev, send to next
                        System.out.println("Processor " + id + " forwards OUT message " + newMsg + " to " + next.getId());
                        next.receiveHSMessage(newMsg.senderId, newMsg.direction, newMsg.hops, false);
                    }
                } 
                // 3. Message is from lower ID - discard
                else if (msg.senderId < id) {
                    discardedMessageCount++;
                    System.out.println("Processor " + id + " discards OUT message from " + msg.senderId + " due to smaller ID.");
                }
            } 
            // Hop count is 1 - change direction to inward
            else if (msg.hops == 1) {
                // 1. Message is our own - shouldn't happen for outgoing
                if (msg.senderId == id) {
                    isLeader = true;
                    leaderId = id;
                    terminated = true;
                    System.out.println("Processor " + id + " detects it's the leader (received own message with hop=1)!");
                    return;
                }
                
                // 2. Message is from other processor - change direction
                if (msg.senderId > id) {  // Only forward if from higher ID
                    Message newMsg = new Message(msg.senderId, "in", 1, msg.fromNext);
                    
                    // Send back in opposite direction
                    if (msg.fromNext) {
                        // Came from next, send back to next
                        System.out.println("Processor " + id + " changes direction and forwards IN message " + newMsg + " to " + next.getId());
                        next.receiveHSMessage(newMsg.senderId, newMsg.direction, newMsg.hops, false);
                    } else {
                        // Came from prev, send back to prev
                        System.out.println("Processor " + id + " changes direction and forwards IN message " + newMsg + " to " + prev.getId());
                        prev.receiveHSMessage(newMsg.senderId, newMsg.direction, newMsg.hops, true);
                    }
                } else {
                    discardedMessageCount++;
                    System.out.println("Processor " + id + " discards OUT message from " + msg.senderId + " due to smaller ID.");
                }
            }
        } 
        // Handle incoming messages
        else if (msg.direction.equals("in")) {
            // 1. Message is our own - advance phase
            if (msg.senderId == id) {
                if (msg.fromNext) {
                    receivedOwnInCounterClockwise = true;
                    System.out.println("Processor " + id + " received its own counterclockwise IN message");
                } else {
                    receivedOwnInClockwise = true;
                    System.out.println("Processor " + id + " received its own clockwise IN message");
                }
                
                // Only advance phase when both directions have returned
                if (receivedOwnInClockwise && receivedOwnInCounterClockwise) {
                    System.out.println("Processor " + id + " advances to phase " + (phase + 1));
                    phase++;
                    sentOutward = false;
                    receivedOwnInClockwise = false;
                    receivedOwnInCounterClockwise = false;
                }
            }
            // 2. Message is from other processor - forward to its destination
            else {
                Message newMsg = new Message(msg.senderId, "in", 1, msg.fromNext);
                
                // Forward in same direction it was received
                if (msg.fromNext) {
                    // From next, send to prev
                    System.out.println("Processor " + id + " forwards IN message " + newMsg + " to " + prev.getId());
                    prev.receiveHSMessage(newMsg.senderId, newMsg.direction, newMsg.hops, true);
                } else {
                    // From prev, send to next
                    System.out.println("Processor " + id + " forwards IN message " + newMsg + " to " + next.getId());
                    next.receiveHSMessage(newMsg.senderId, newMsg.direction, newMsg.hops, false);
                }
            }
        }
    }

    public void receiveHSMessage(int senderId, String direction, int hops, boolean fromNext) {
        if (terminated) return;
        
        Message msg = new Message(senderId, direction, hops, fromNext);
        System.out.println("Processor " + id + " received " + direction.toUpperCase() + " message " + msg);
        
        // If we receive our own outgoing message with hops > 0, we're the leader (completed circuit)
        if (senderId == id && direction.equals("out") && hops > 0) {
            isLeader = true;
            leaderId = id;
            terminated = true;
            System.out.println("Processor " + id + " elected as leader (received own outward message)!");
            return;
        }
        
        // Add to pending messages queue to be processed in the next round
        pendingHSMessages.add(msg);
    }

    public boolean processHSReceivedMessages() {
        if (terminated) return isLeader;
        return false;
    }
    
    public void receiveLeaderAnnouncement(int newLeaderId) {
        // If we thought we were the leader but a higher ID processor claims leadership,
        // we defer to the higher ID
        if (isLeader && newLeaderId > id) {
            System.out.println("Processor " + id + " defers leadership to higher ID processor " + newLeaderId);
            isLeader = false;
        }
        
        leaderId = newLeaderId;
        maxKnownId = newLeaderId;
        terminated = true;
        System.out.println("Processor " + id + " acknowledges leader: " + leaderId);
    }
    
    public int getDiscardedMessageCount() {
        return discardedMessageCount;
    }
}