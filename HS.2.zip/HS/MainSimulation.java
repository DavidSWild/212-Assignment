import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Random;
import java.util.HashSet;

public class MainSimulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numProcessors;

        while (true) {
            try {
                System.out.print("Enter the number of processors (>= 2): ");
                numProcessors = Integer.parseInt(scanner.nextLine());

                if (numProcessors >= 2) {
                    break;
                } else {
                    System.out.println("Number of processors must be at least 2. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }

        Random random = new Random();
        HashSet<Integer> uniqueIds = new HashSet<>();
        List<Integer> ids = new ArrayList<>();

        while (uniqueIds.size() < numProcessors) {
            int newId = random.nextInt(1000) + 1;
            if (uniqueIds.add(newId)) {
                ids.add(newId);
            }
        }

        System.out.println("\nGenerated Random " + numProcessors + " IDs: " + ids);

        boolean shouldShuffle = false;
        while (true) {
            System.out.println("\nSelect ID configuration:");
            System.out.println("1 - Increasing Order");
            System.out.println("2 - Decreasing Order");
            System.out.println("3 - Random Order");
            System.out.print("Enter your choice (1-3): ");

            String choice = scanner.nextLine();
            if (choice.equals("1")) {
                Collections.sort(ids);
                break;
            } else if (choice.equals("2")) {
                ids.sort(Collections.reverseOrder());
                break;
            } else if (choice.equals("3")) {
                Collections.shuffle(ids);
                shouldShuffle = true;
                break;
            } else {
                System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }

        List<Processor> processors = new ArrayList<>();
        for (int id : ids) {
            processors.add(new Processor(id));
        }

        if (shouldShuffle) {
            Collections.shuffle(processors);
        }

        for (int i = 0; i < numProcessors; i++) {
            processors.get(i).setNext(processors.get((i + 1) % numProcessors));
            processors.get(i).setPrev(processors.get((i - 1 + numProcessors) % numProcessors));
        }

        System.out.println("\nRing Topology:");
        for (Processor p : processors) {
            System.out.println("Processor " + p.getId() + " -> Next: Processor " + p.getNextId());
        }

        System.out.println("\nSelect Leader Election Algorithm:");
        System.out.println("1 - LCR Algorithm");
        System.out.println("2 - HS Algorithm");
        System.out.print("Enter your choice (1-2): ");
        String algoChoice = scanner.nextLine();

        int leaderId = -1;
        int electionRounds;
        if (algoChoice.equals("1")) {
            electionRounds = DistributedAlgorithm.simulate(processors);
        } else if (algoChoice.equals("2")) {
            electionRounds = HSAlgorithm.simulate(processors);
        } else {
            System.out.println("Invalid choice. Defaulting to LCR.");
            electionRounds = DistributedAlgorithm.simulate(processors);
        }

        // Ensure we correctly get the elected leader
        for (Processor p : processors) {
            if (p.isLeader()) {
                leaderId = p.getId();
                break;
            }
        }

        int floodingRounds = UnidirectionalFlooding.announceLeader(processors, leaderId);

        System.out.println("\n======= Final Statistics =======");
        System.out.println("Election Algorithm:");
        System.out.println("  - Rounds: " + electionRounds);
        System.out.println("  - Messages: " + (algoChoice.equals("1") ? DistributedAlgorithm.getTotalLCRMessages() : HSAlgorithm.getTotalHSMessages()));
        System.out.println("\nFlooding Algorithm:");
        System.out.println("  - Rounds: " + floodingRounds);
        System.out.println("  - Messages: " + UnidirectionalFlooding.getTotalFloodingMessages());
        System.out.println("\nTotal:");
        System.out.println("  - Rounds: " + (electionRounds + floodingRounds));
        System.out.println("  - Messages: " + (algoChoice.equals("1") ? DistributedAlgorithm.getTotalLCRMessages() + UnidirectionalFlooding.getTotalFloodingMessages() : HSAlgorithm.getTotalHSMessages() + UnidirectionalFlooding.getTotalFloodingMessages()));
        System.out.println("=============================");

        scanner.close();
    }
}
