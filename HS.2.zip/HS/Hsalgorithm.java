import java.util.List;

class HSAlgorithm {
    private static int totalHSMessages = 0;

    public static void resetMessageCount() {
        totalHSMessages = 0;
    }

    public static int getTotalHSMessages() {
        return totalHSMessages;
    }

    public static int simulate(List<Processor> processors) {
        resetMessageCount();
        int round = 0;
        boolean leaderFound = false;
        int leaderId = -1;
        boolean allTerminated = false;
        
        // Safety parameters - much higher now that we have a correct implementation
        int maxRounds = processors.size() * 4; // Should be plenty for O(log n) rounds
        int consecutiveNoMessageRounds = 0;
        final int MAX_NO_MESSAGE_ROUNDS = 3;

        // Initialize processors for HS
        for (Processor p : processors) {
            p.initHS();
        }

        while (!allTerminated) {
            round++;
            System.out.println("\n--- HS Election: Round " + round + " ---");
            boolean anyMessageSent = false;

            // Phase 1: Send messages
            for (Processor p : processors) {
                if (p.hasHSMessageToSend()) {
                    totalHSMessages++;
                    p.sendHSMessage();
                    anyMessageSent = true;
                }
            }
            
            // Track consecutive rounds with no messages
            if (!anyMessageSent) {
                consecutiveNoMessageRounds++;
                System.out.println("No messages sent in this round.");
            } else {
                consecutiveNoMessageRounds = 0;
            }

            // Phase 2: Check for leaders
            for (Processor p : processors) {
                if (p.isLeader() && !leaderFound) {
                    leaderFound = true;
                    leaderId = p.getId();
                    System.out.println("Leader found: Processor " + leaderId);
                }
            }

            // If a leader is found, announce it to all processors
            if (leaderFound && leaderId != -1) {
                for (Processor p : processors) {
                    if (!p.isLeader() && !p.hasTerminated()) {
                        p.receiveLeaderAnnouncement(leaderId);
                    }
                }
            }

            // Check if all processors have terminated
            allTerminated = true;
            for (Processor p : processors) {
                if (!p.hasTerminated()) {
                    allTerminated = false;
                    break;
                }
            }

            // Safety check 1: If no messages for several consecutive rounds, check if we need to force termination
            if (consecutiveNoMessageRounds >= MAX_NO_MESSAGE_ROUNDS && !allTerminated) {
                System.out.println("WARNING: No messages sent for " + consecutiveNoMessageRounds + " consecutive rounds.");
                
                // Find highest ID processor if no leader yet
                if (leaderId == -1) {
                    int highestId = -1;
                    int highestIdIndex = -1;
                    for (int i = 0; i < processors.size(); i++) {
                        Processor p = processors.get(i);
                        if (p.getId() > highestId) {
                            highestId = p.getId();
                            highestIdIndex = i;
                        }
                    }
                    
                    if (highestIdIndex != -1) {
                        leaderId = highestId;
                        processors.get(highestIdIndex).setAsLeader(leaderId);
                        System.out.println("Forcing processor " + leaderId + " (highest ID) to be leader");
                        leaderFound = true;
                    }
                }
                
                // Announce leader to all processors
                for (Processor p : processors) {
                    if (!p.isLeader() && !p.hasTerminated()) {
                        p.receiveLeaderAnnouncement(leaderId);
                    }
                }
                
                allTerminated = true;
            }

            // Safety check 2: Maximum round limit (should almost never be needed now)
            if (round > maxRounds) {
                System.out.println("WARNING: Reached maximum round limit of " + maxRounds + ". Forcing termination.");
                
                // Find highest ID processor if no leader yet
                if (leaderId == -1) {
                    int highestId = -1;
                    int highestIdIndex = -1;
                    for (int i = 0; i < processors.size(); i++) {
                        Processor p = processors.get(i);
                        if (p.getId() > highestId) {
                            highestId = p.getId();
                            highestIdIndex = i;
                        }
                    }
                    
                    if (highestIdIndex != -1) {
                        leaderId = highestId;
                        processors.get(highestIdIndex).setAsLeader(leaderId);
                        System.out.println("Forcing processor " + leaderId + " (highest ID) to be leader");
                    }
                }
                
                // Announce leader to all processors
                for (Processor p : processors) {
                    if (!p.isLeader() && !p.hasTerminated()) {
                        p.receiveLeaderAnnouncement(leaderId);
                    }
                }
                
                allTerminated = true;
            }
        }

        // Print summary statistics
        System.out.println("\n=== HS Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalHSMessages);
        System.out.println("Leader elected: Processor " + leaderId);
        System.out.println("============================");

        return round;
    }
}