import java.util.List;
import java.util.ArrayList;

public class HSAlgorithm {
    private static int totalMessages = 0;

    public static void resetMessageCount() {
        totalMessages = 0;
    }

    public static int getTotalMessages() {
        return totalMessages; 
    }

    public static int simulate(List<HSProcessor> processors) {
        resetMessageCount();
        
        // Initialize variables
        int round = 0;
        boolean changed = true;
        int leaderId = -1;
        int maxPhase = 0;
        int consecutiveNoMessageRounds = 0;
        final int MAX_NO_MESSAGE_ROUNDS = 3;
        
        // Set a better round limit based on O(log n) theoretical bound
        // Use 2*log₂(n) + 10 as a safe upper bound for the number of phases
        // Since each phase may take multiple rounds, multiply by 2
        int maxRounds = (int)(4 * Math.log(processors.size()) / Math.log(2)) + 10;

        // Initialize all processors
        for (HSProcessor p : processors) {
            p.initialise();
        }

        // Main algorithm loop
        while (changed && round < maxRounds) {
            round++;
            changed = false;
            boolean messagesSent = false;
            
            // Update maximum phase reached
            for (HSProcessor p : processors) {
                if (p.getPhase() > maxPhase) {
                    maxPhase = p.getPhase();
                }
            }
            
            System.out.println("\n--- HS Election: Round " + round + " (Max Phase: " + maxPhase + ") ---");

            // Check for leader election
            System.out.println("\n[Processing Messages]");
            for (HSProcessor p : processors) {
                if (p.isLeader() && leaderId == -1) {
                    leaderId = p.getId();
                    changed = true;
                    System.out.println("Leader detected: Processor " + leaderId);
                    
                    // Terminate other processors to reduce unnecessary messages
                    for (HSProcessor other : processors) {
                        if (other.getId() != leaderId) {
                            other.setTerminated(true);
                        }
                    }
                }
            }

            // Send messages
            System.out.println("\n[Sending Messages]");
            for (HSProcessor p : processors) {
                if (p.hasMessagesToSend()) {
                    int messageCount = p.sendMessages();
                    totalMessages += messageCount;
                    
                    if (messageCount > 0) {
                        messagesSent = true;
                        changed = true;
                    }
                }
            }
            
            // Output round status
            System.out.println("\nStatus after Round " + round + ":");
            for (HSProcessor p : processors) {
                System.out.printf("  Processor %d: Phase=%d, %s%n", 
                    p.getId(), p.getPhase(), p.isLeader() ? "IS LEADER" : "not leader");
            }
            
            // Check for termination conditions
            if (!messagesSent) {
                consecutiveNoMessageRounds++;
                System.out.println("No messages sent for " + consecutiveNoMessageRounds + " consecutive rounds");
            } else {
                consecutiveNoMessageRounds = 0;
            }
            
            // Termination conditions
            if (leaderId != -1 || consecutiveNoMessageRounds >= MAX_NO_MESSAGE_ROUNDS) {
                if (leaderId != -1) {
                    System.out.println("Algorithm terminated: Leader elected.");
                } else {
                    System.out.println("Algorithm terminated: Message passing stabilized without leader election.");
                }
                break;
            }
        }

        // If no leader was elected after maximum rounds, select highest ID processor
        if (leaderId == -1) {
            System.out.println("\nReached maximum rounds (" + maxRounds + ") without natural termination.");
            
            // Find processor with highest ID
            int highestId = Integer.MIN_VALUE;
            HSProcessor highestProcessor = null;
            
            for (HSProcessor p : processors) {
                if (p.getId() > highestId) {
                    highestId = p.getId();
                    highestProcessor = p;
                }
            }
            
            if (highestProcessor != null) {
                highestProcessor.setTerminated(true);
                leaderId = highestId;
                System.out.println("Designating processor with highest ID (" + leaderId + ") as leader.");
            }
        }

        // Output summary statistics
        System.out.println("\n=== HS Algorithm Summary ===");
        System.out.println("Rounds completed: " + round);
        System.out.println("Messages sent: " + totalMessages);
        
        if (leaderId != -1) {
            System.out.println("Leader elected: Processor " + leaderId);
        } else {
            System.out.println("Leader elected: None");
        }
        
        System.out.println("Maximum phase reached: " + maxPhase);
        
        // Check for multiple leaders (error condition)
        List<Integer> selfDeclaredLeaders = new ArrayList<>();
        for (HSProcessor p : processors) {
            if (p.isLeader()) {
                selfDeclaredLeaders.add(p.getId());
            }
        }
        
        if (!selfDeclaredLeaders.isEmpty()) {
            System.out.println("Processors that believe they are leaders: " + selfDeclaredLeaders);
            if (selfDeclaredLeaders.size() > 1) {
                System.out.println("WARNING: Multiple processors believe they are leaders!");
            }
        } else {
            System.out.println("No processor believes it is the leader.");
            
            // If no leader but we assigned one, mark it as leader
            if (leaderId != -1) {
                for (HSProcessor p : processors) {
                    if (p.getId() == leaderId) {
                        p.setTerminated(true);
                        System.out.println("Setting processor " + leaderId + " as leader.");
                        break;
                    }
                }
            }
        }
        
        System.out.println("============================");

        return round;
    }
}