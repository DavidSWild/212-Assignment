import java.util.ArrayList;
import java.util.List;

public class HSProcessor {
    private final int id;
    private HSProcessor next;
    private HSProcessor prev;
    private boolean isLeader = false;
    private int phase = 0;
    private boolean seenHigherId = false;
    private boolean terminated = false;
    
    // Message queues for both directions
    private List<int[]> clockwiseMessages = new ArrayList<>();
    private List<int[]> counterclockwiseMessages = new ArrayList<>();
    
    // Track if messages returned from both directions
    private boolean receivedClockwise = false;
    private boolean receivedCounterclockwise = false;

    public HSProcessor(int id) {
        this.id = id;
    }

    // Ring connections
    public void setNext(HSProcessor next) {
        this.next = next;
    }

    public void setPrev(HSProcessor prev) {
        this.prev = prev;
    }

    // Getters
    public int getId() {
        return id;
    }

    public int getNextId() {
        return next != null ? next.id : -1;
    }
    
    public int getPrevId() {
        return prev != null ? prev.id : -1;
    }

    public boolean isLeader() {
        return isLeader;
    }
    
    public int getPhase() {
        return phase;
    }
    
    public boolean isTerminated() {
        return terminated;
    }
    
    public void setTerminated(boolean terminated) {
        this.terminated = terminated;
    }
    
    // Initialize processor for a new algorithm run
    public void initialise() {
        isLeader = false;
        phase = 0;
        clockwiseMessages.clear();
        counterclockwiseMessages.clear();
        receivedClockwise = false;
        receivedCounterclockwise = false;
        seenHigherId = false;
        terminated = false;
        
        // Add initial outgoing messages in both directions with hop count 1
        clockwiseMessages.add(new int[] {id, 0, 1});
        counterclockwiseMessages.add(new int[] {id, 0, 1});
    }
    
    // Check if processor has messages to send
    public boolean hasMessagesToSend() {
        return !terminated && (!clockwiseMessages.isEmpty() || !counterclockwiseMessages.isEmpty());
    }
    
    // Send messages in both directions if available
    public int sendMessages() {
        if (terminated) {
            return 0;
        }
        
        int count = 0;
        
        // Send clockwise
        if (!clockwiseMessages.isEmpty()) {
            int[] msg = clockwiseMessages.remove(0);
            next.receiveCounterclockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (clockwise)%n", 
                id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], next.getId());
            count++;
        }
        
        // Send counterclockwise
        if (!counterclockwiseMessages.isEmpty()) {
            int[] msg = counterclockwiseMessages.remove(0);
            prev.receiveClockwiseMessage(msg);
            System.out.printf("Processor %d sends [id=%d, dir=%s, hop=%d] -> Processor %d (counterclockwise)%n", 
                id, msg[0], (msg[1] == 0 ? "OUT" : "IN"), msg[2], prev.getId());
            count++;
        }
        
        return count;
    }
    
    // Receive message from counterclockwise neighbor (coming clockwise)
    public void receiveClockwiseMessage(int[] message) {
        if (terminated) {
            return;
        }
        
        int[] msg = message.clone();
        processMessage(msg, true);
    }
    
    // Receive message from clockwise neighbor (coming counterclockwise)
    public void receiveCounterclockwiseMessage(int[] message) {
        if (terminated) {
            return;
        }
        
        int[] msg = message.clone();
        processMessage(msg, false);
    }
    
    // Process received messages
    private void processMessage(int[] message, boolean fromClockwise) {
        int incomingId = message[0];
        int direction = message[1];  // 0 = OUT, 1 = IN
        int hopCount = message[2];
        
        System.out.printf("Processor %d received [id=%d, dir=%s, hop=%d] from %s%n", 
            id, incomingId, (direction == 0 ? "OUT" : "IN"), hopCount, (fromClockwise ? "clockwise" : "counterclockwise"));
        
        // CASE 1: Own message returned after completing full circle or hop count reached 0
        if (incomingId == id && direction == 0 && (hopCount == 0 || 
            (fromClockwise && !receivedClockwise) || (!fromClockwise && !receivedCounterclockwise))) {
            
            // Record direction from which we received our own message
            if (fromClockwise) {
                receivedClockwise = true;
                System.out.println("Processor " + id + " received own message from clockwise direction");
            } else {
                receivedCounterclockwise = true;
                System.out.println("Processor " + id + " received own message from counterclockwise direction");
            }
            
            // Check if we can be leader (received from both directions && no higher ID seen)
            if (receivedClockwise && receivedCounterclockwise && !seenHigherId) {
                isLeader = true;
                terminated = true; // Terminate to prevent further messaging
                System.out.println("*** Processor " + id + " elected as leader (received own message from both directions) ***");
            } else if (receivedClockwise && receivedCounterclockwise) {
                // If received from both directions but can't be leader (saw higher ID)
                // then advance to next phase
                advancePhase();
            }
            return;
        }
        
        // CASE 2: Process outgoing messages from other processors
        if (direction == 0) {
            if (incomingId > id) {
                // We've seen a higher ID - can't be leader
                seenHigherId = true;
                
                if (hopCount > 1) {
                    // Forward message with decremented hop count
                    if (fromClockwise) {
                        clockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    } else {
                        counterclockwiseMessages.add(new int[] {incomingId, 0, hopCount - 1});
                    }
                } else if (hopCount == 1) {
                    // Last hop - change to IN direction for return trip
                    if (fromClockwise) {
                        counterclockwiseMessages.add(new int[] {incomingId, 1, 1});
                    } else {
                        clockwiseMessages.add(new int[] {incomingId, 1, 1});
                    }
                }
            } else if (incomingId < id) {
                // Discard messages from lower IDs
                System.out.println("Processor " + id + " discarded message from lower ID " + incomingId);
            } else if (incomingId == id) {
                // Handle our own returning message after circuit
                if (fromClockwise) {
                    receivedClockwise = true;
                    System.out.println("Processor " + id + " received own returning message (clockwise)");
                } else {
                    receivedCounterclockwise = true;
                    System.out.println("Processor " + id + " received own returning message (counterclockwise)");
                }
                
                // Check if we can be leader
                if (receivedClockwise && receivedCounterclockwise && !seenHigherId) {
                    isLeader = true;
                    terminated = true;
                    System.out.println("*** Processor " + id + " elected as leader (full circuit) ***");
                } else if (receivedClockwise && receivedCounterclockwise) {
                    advancePhase();
                }
            }
        }
        // CASE 3: Process incoming (returning) messages
        else if (direction == 1) {
            if (incomingId == id) {
                // Our own message is returning
                if (fromClockwise) {
                    receivedClockwise = true;
                    System.out.println("Processor " + id + " received own IN message (clockwise)");
                } else {
                    receivedCounterclockwise = true;
                    System.out.println("Processor " + id + " received own IN message (counterclockwise)");
                }
                
                // Check if we received from both directions
                if (receivedClockwise && receivedCounterclockwise) {
                    if (!seenHigherId) {
                        isLeader = true;
                        terminated = true;
                        System.out.println("*** Processor " + id + " elected as leader (received own IN message from both directions) ***");
                    } else {
                        advancePhase();
                    }
                }
            } else {
                // Forward another processor's returning message
                if (incomingId > id) {
                    seenHigherId = true;
                }
                
                // Forward the message toward its origin
                if (fromClockwise) {
                    counterclockwiseMessages.add(message.clone());
                } else {
                    clockwiseMessages.add(message.clone());
                }
            }
        }
    }
    
    // Advance to next phase with doubled hop count (2^phase)
    private void advancePhase() {
        phase++;
        int newHopCount = (int)Math.pow(2, phase);
        
        // Reset received flags for the new phase
        receivedClockwise = false;
        receivedCounterclockwise = false;
        
        // Add new outgoing messages with increased hop count
        clockwiseMessages.add(new int[] {id, 0, newHopCount});
        counterclockwiseMessages.add(new int[] {id, 0, newHopCount});
        
        System.out.println("Processor " + id + " advancing to phase " + phase + " with hop count " + newHopCount);
    }
}